<!DOCTYPE html>
<html lang="en">
<head>
  <title>IRB</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    /* Remove the jumbotron's default bottom margin */ 
     .jumbotron {
      margin-bottom: 0;
    }
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
    .left{

      text-align:left;
    }
    #myInput {
          background-image: url('./images/searchicon.png');
          background-position: 10px 10px;
          background-repeat: no-repeat;
          width: 100%;
          font-size: 16px;
          padding: 12px 20px 12px 40px;
          border: 1px solid #ddd;
          margin-bottom: 12px;
}
.heading {
    color: #9a0130;
    font-size: 40px;
    font-weight: 800;
    line-height: 112px;
    text-align: center;
}
  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container">
  <div class="col-sm-3">
    <img src="images/logo.png" height="150px" />
      <h4>Believe in Possibilities</h4>
  </div>  
    <div class="col-sm-6 left">
  
   <br/>
   <br/>
   <h2 class="heading">Welcome to IRB Home Page</h2>
  </div>   
    <div class="col-sm-3">
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search .." title="Type in a name">

<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
  </div>     
  </div>
</div><div class="container">
  <div class="col-sm-3">
  <a href="user/user_login.php"> <button type="button" class="btn btn-primary btn-lg">Student</button></a>
  </div>
  <div class="col-sm-3">
 <a href="faculty/faculty_login.php"> <button type="button" class="btn btn-primary btn-lg">Faculty</button></a>
  </div>
  <div class="col-sm-3">
  <a href="irb/index.php"><button type="button" class="btn btn-primary btn-lg">IRB Member</button></a>
  </div>
  <div class="col-sm-3">
  <a href="admin/index.php"><button type="button" class="btn btn-primary btn-lg">ADMIN</button></a>
  </div>
  </div>
  <br/>
  <br/>
<div class="container"> 
<div class="container-fluid">
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="slider/1.jpg" alt="Chania">
      </div>
      <div class="item">
        <img src="slider/2.jpg" alt="Chania">
      </div>
      <div class="item">
        <img src="slider/3.jpg" alt="Flower">
      </div>
      <div class="item">
        <img src="slider/4.png" alt="Flower">
      </div>
    </div>
    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span> </a>
  </div>
</div>
<br/>
<br/>
  <div class="container">
  <div class="col-sm-3">
  <a href="user/user_login.php"> <button type="button" class="btn btn-primary btn-lg">Student</button></a>
  </div>
  <div class="col-sm-3">
 <a href="faculty/faculty_login.php"> <button type="button" class="btn btn-primary btn-lg">Faculty</button></a>
  </div>
  <div class="col-sm-3">
  <a href="irb/index.php"><button type="button" class="btn btn-primary btn-lg">IRB Member</button></a>
  </div>
  <div class="col-sm-3">
  <a href="admin/index.php"><button type="button" class="btn btn-primary btn-lg">ADMIN</button></a>
  </div>
  </div>
  <br/>
  <br/>
<div class="container">    
  <div class="row">
    <div class="col-sm-2">
    </div>
    <div class="col-sm-8"> 
      <div class="panel panel-danger">
        <div class="panel-heading">If You Have questions please contact us </div>
        <div class="panel-body">
          <div class="form-group">
<form action="" method="post">
              <label for="usr">Name:</label> 
              <input type="text" class="form-control" id="usr" name="name" required="">
          </div>
          <div class="form-group">
              <label for="pwd">Email:</label>
              <input type="email" class="form-control" id="pwd" name="email" required="">
          </div>
           <div class="form-group">
              <label for="pwd">Question:</label>
              <input type="text" class="form-control" id="pwd" name="question" required="">
          </div>
             <div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg" name="q1">Submit</button>

          </div>
</form>
           
        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
    <div class="col-sm-2"> 
     
    </div>
  </div>
</div><br>



<footer class="container-fluid text-center">
  <p> Copyright</p>  
  
</footer>

</body>
</html>

<?php
if(isset($_REQUEST['q1']))
{
include('connection.php');

$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$question=$_REQUEST['question'];

$sql=mysql_query("INSERT INTO `feedback` (
`id` ,
`name` ,
`email` ,
`question`
)
VALUES (
NULL , '$name', '$email', '$question'
)");

if($sql)
{
  echo "<script>alert('succesfully insert'); window.location='index.php'</script>";

}
else
{
  echo "<script>alert('error insert'); window.location='index.php'</script>";

}

}
?>








