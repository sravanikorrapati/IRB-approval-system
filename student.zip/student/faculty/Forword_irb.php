<?php

include('header.php');
$sponsorshipid=$_REQUEST['id'];
$userid=$_REQUEST['userid'];
$username=$_REQUEST['username'];
$facultid=$_REQUEST['facult'];


?>
			<div id="page-wrapper">
				<div class="container">    
  <div class="row">
    <div class="col-sm-2">
   
    </div>
    <div class="col-sm-8"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Forword Sponsorship Request to IRB </div>
        <div class="panel-body">
			<form action="" method="post">
			 <div class="form-group">
				<label for="sel1">Select IRB MEMBER:</label>
				<select class="form-control" id="sel1" required="" name="irb_member">
					<?php
					$sql=mysql_query("select * from irb");
					while($result=mysql_fetch_array($sql))
					{
					?>
					<option value="<?php echo $result[0];?>"><?php echo $result[1];?></option>
					<?php
					}
					?>
				</select>
			</div>

			

			 <div class="form-group">
              <label for="pwd">Student name:</label>
              <input type="text" value="<?php echo $username;?>" class="form-control" id="pwd" name="question" required="">
          </div>
          <?php
          	$sql=mysql_query("SELECT * FROM `sponsorship` where userid='$userid'");
          	$result=mysql_fetch_array($sql);
          	//print_r($result);
          
          	          ?>
         <div class="form-group">
              <label for="pwd">Question:</label>
              <input type="text" class="form-control" id="pwd" name="question" required="" value="<?php echo $result['question'];?>" />
          </div>
		<div class="form-group">
			<label for="comment">Description:</label>
			<textarea class="form-control" rows="5" id="comment" name="description" value=""><?php echo $result['description'];?></textarea>
		</div> 
             <div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg" name="q1">Submit</button>

          </div>
</form>
           
        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
    <div class="col-sm-2"> 
     
    </div>
			</div>
			<?php
		if(isset($_REQUEST['q1']))
		{

			$irb_member=$_REQUEST['irb_member'];
			$question=$_REQUEST['question'];
			$description=$_REQUEST['description'];
			
$sponsorshipid=$_REQUEST['id'];
$userid=$_REQUEST['userid'];
$username=$_REQUEST['username'];
$facultid=$_REQUEST['facult'];


			$result=mysql_query("INSERT INTO `student`.`sponsorship_irb` (
			`siid`,
			`fid`,
			`sid`,
			`irb_id`,
			`question` ,
			`description` ,
			`status` ,
			`date`
			)
			VALUES (
			NULL , '$facultid', '$userid','$irb_member','$question', '$description', '0',
			CURRENT_TIMESTAMP
			)");

	

		//print_r($result);
	
		
		if($result)
		{	
			$sponsorshipid=$_REQUEST['id'];

			$res=mysql_query("UPDATE `student`.`sponsorship` SET `appstatus` = '1' WHERE `sponsorship`.`sid` ='$sponsorshipid'");





			echo "<script> alert('submit  sponsorship request'); window.location='profile.php';</script>";

		}
		else
		{

			echo "<script> alert('error  sponsorship request'); window.location='profile.php';</script>";

		}

		}
		?>


				<?php
		include('footer.php');?>


		
		