<?php
include('../connection.php');

	error_reporting(0);

					$typeofreview=$_REQUEST['r1'];
					$Principalinvestigator=$_REQUEST['Principal_ans'];
					$study_propos=$_REQUEST['study_propos'];

					$inves_mail=$_REQUEST['inves_mail'];

					$inves_tele=$_REQUEST['inves_tele'];
					$email_invester=$_REQUEST['email_invester'];
					$status=$_REQUEST['status'];
					$Sponsor_name=$_REQUEST['Sponsor_name'];

					$fac_office=$_REQUEST['fac_office'];
					$address=$_REQUEST['address'];
					$telephone=$_REQUEST['telephone'];
					$inves_mail=$_REQUEST['email'];

					$coinvestigators=$_REQUEST['co-investigators'];
					$co_invetname=$_REQUEST['co_invet'];
					$co_invet_mail=$_REQUEST['co_invet_mail'];
					$co_invet_email=$_REQUEST['co_invet_email'];

					$co_invet_tele=$_REQUEST['co_invet_tele'];
					$check=$_REQUEST['chk1'];

					$applicable_categories=implode(',', $check);
					$grnt_app=$_REQUEST['grnt_app'];
					$start_data=$_REQUEST['start_date'];
					$IRB_approval=$_REQUEST['r2'];


					$end_data=$_REQUEST['end_date'];
					$projected_study=$_REQUEST['r3'];
					$purpose=$_REQUEST['purpose'];
					$methodology=$_REQUEST['methodology'];


					$subject=$_REQUEST['r4'];
					$vulnerable=$_REQUEST['r5'];

					$population=$_REQUEST['population'];
					$recruited=$_REQUEST['recruited'];

					$solicited=implode(',', $_REQUEST['chk5']);


					$chk9=$_REQUEST['chk9'];
					$research_subjects=implode(',', $chk9);

					$risk=$_REQUEST['r6'];
					$Experimental=$_REQUEST['r7'];
					$Potential=$_REQUEST['r8'];


					$physical=$_REQUEST['r9'];
					$mental=$_REQUEST['r10'];
					$Electrical=$_REQUEST['r11'];
					$photographed=$_REQUEST['r12'];


					$coercion=$_REQUEST['r13'];
					$exposed=$_REQUEST['r14'];
					$benefits=$_REQUEST['benefits'];
					$research=$_REQUEST['research'];
					$rewarded=$_REQUEST['r15'];
					$Choose_one=$_REQUEST['r18'];

					$userid=$_REQUEST['userid'];
					$res=mysql_query("select * from faculty where email='$userid'");
					$result=mysql_fetch_array($res);
					 $userid1=$result[0];


if(isset($_REQUEST['s1']))
{

$result=mysql_query("INSERT INTO `review_faculty` (`rid`, `Type_of_review`, `Principal_investigator`, `Title_of_Research_Study_Proposal`, `Investigator_mailing`, `Investigator_telephone`, `Email`, `Status`, `Sponsorname_and_degree`, `Faculty_sponsor_office`, `Mailing_address`, `Telephone`, `E-mail`, `Are_there_co-investigators`, `CO_INVESTIGATORS_names`, `Co_investigator_mailing_address`, ` Co_investigator_email_address`, `co_investigator_telephone_number`, `applicable_categories`, `grant_application`, `IRB_approval`, ` start_date`, `end_date`, `study_duration`, `esearch_qution`, `METHODOLOGY`, `SUBJECTS`, `vulnerable_population`, `rationale`, `number_of_subjects`, `recruited`, ` criteria`, `drugs`, `medical`, ` physical_discomfort`, `mental_discomfort`, `Electrical _equipment`, `photographed`, `coercion`, `exposed`, `research_study`, ` general_knowledge`, ` rewarded`, `Choose one`,`faculty_id`,`status_submit`) VALUES (NULL, '$typeofreview', '$Principalinvestigator', '$study_propos', '$inves_mail', '$inves_tele', '$email_invester', '$status', '$Sponsor_name', '$fac_office', '$address', '$telephone', '$inves_mail', '$coinvestigators', '$co_invetname', '$co_invet_mail', '$co_invet_email', '$co_invet_tele', '$applicable_categories', '$grnt_app', '$IRB_approval', '$start_data', '$end_data', '$projected_study', '$purpose', '$methodology', '$subject', '$vulnerable', '$population', '$recruited', '$solicited', '$risk', '$Experimental', '$Potential', '$physical', '$mental', '$Electrical', '$photographed', '$coercion', '$exposed', '$benefits', '$research', '$rewarded', '$Choose_one','$userid1',0)");

if($result)
{

	echo "<script>alert('save feedback'); window.location='profile.php'</script>";


}
else
{

echo "<script>alert('error feedback'); window.location='review.php'</script>";


}
}
if(isset($_REQUEST['s2']))
{

$result=mysql_query("INSERT INTO `review_faculty` (`rid`, `Type_of_review`, `Principal_investigator`, `Title_of_Research_Study_Proposal`, `Investigator_mailing`, `Investigator_telephone`, `Email`, `Status`, `Sponsorname_and_degree`, `Faculty_sponsor_office`, `Mailing_address`, `Telephone`, `E-mail`, `Are_there_co-investigators`, `CO_INVESTIGATORS_names`, `Co_investigator_mailing_address`, ` Co_investigator_email_address`, `co_investigator_telephone_number`, `applicable_categories`, `grant_application`, `IRB_approval`, ` start_date`, `end_date`, `study_duration`, `esearch_qution`, `METHODOLOGY`, `SUBJECTS`, `vulnerable_population`, `rationale`, `number_of_subjects`, `recruited`, ` criteria`, `drugs`, `medical`, ` physical_discomfort`, `mental_discomfort`, `Electrical _equipment`, `photographed`, `coercion`, `exposed`, `research_study`, ` general_knowledge`, ` rewarded`, `Choose one`,`faculty_id`,`status_submit`) VALUES (NULL, '$typeofreview', '$Principalinvestigator', '$study_propos', '$inves_mail', '$inves_tele', '$email_invester', '$status', '$Sponsor_name', '$fac_office', '$address', '$telephone', '$inves_mail', '$coinvestigators', '$co_invetname', '$co_invet_mail', '$co_invet_email', '$co_invet_tele', '$applicable_categories', '$grnt_app', '$IRB_approval', '$start_data', '$end_data', '$projected_study', '$purpose', '$methodology', '$subject', '$vulnerable', '$population', '$recruited', '$solicited', '$risk', '$Experimental', '$Potential', '$physical', '$mental', '$Electrical', '$photographed', '$coercion', '$exposed', '$benefits', '$research', '$rewarded', '$Choose_one','$userid1',1)");

if($result)
{

	echo "<script>alert('submit feedback'); window.location='profile.php'</script>";


}
else
{

echo "<script>alert('error feedback'); window.location='review.php'</script>";


}
}

?>

