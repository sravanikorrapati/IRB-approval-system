<?php

include('../connection.php');
	                $typeofreview=$_REQUEST['Type_of_review'];
					 $Principalinvestigator=$_REQUEST['Principal_ans'];
					 $study_propos=$_REQUEST['study_propos'];

					 $inves_mail=$_REQUEST['inves_mail'];

					 $inves_tele=$_REQUEST['inves_tele'];
					 $email_invester=$_REQUEST['email_invester'];
					 $status=$_REQUEST['status'];
					 $Sponsor_name=$_REQUEST['Sponsor_name'];

					 $fac_office=$_REQUEST['fac_office'];
					 $address=$_REQUEST['address'];
					 $telephone=$_REQUEST['telephone'];
					 $inves_mail=$_REQUEST['email'];

					$coinvestigators=$_REQUEST['co-investigators'];
					$co_invetname=$_REQUEST['co_invet'];
					$co_invet_mail=$_REQUEST['co_invet_mail'];
					$co_invet_email=$_REQUEST['co_invet_email'];

					$co_invet_tele=$_REQUEST['co_invet_tele'];
					$study_proposal=$_REQUEST['study_proposal'];
					$grnt_app=$_REQUEST['grnt_app'];
					$start_data=$_REQUEST['start_date'];
					$IRB_approval=$_REQUEST['irb_approval'];
					$funding_agency=$_REQUEST['funding_agency'];
					$end_data=$_REQUEST['end_date'];
					$study_duration=$_REQUEST['study_duration'];
					$purpose=$_REQUEST['purpose'];
					$methodology=$_REQUEST['methodology'];
					$research_subjects=$_REQUEST['research_subjects'];
					$vulnerable_population=$_REQUEST['vulnerable_population'];
					$rationale=$_REQUEST['rationale'];
					$number_of_subjects=$_REQUEST['number_of_subjects'];
					$recruited=$_REQUEST['recruited'];
					$drugs=$_REQUEST['drugs'];
					$medical=$_REQUEST['medical'];
					$physical=$_REQUEST['physical'];
					$mental=$_REQUEST['mental'];
					$Electrical=$_REQUEST['Electrical'];
					$photographed=$_REQUEST['photographed'];
					$coercion=$_REQUEST['coercion'];
					$exposed=$_REQUEST['exposed'];
					$benefits=$_REQUEST['benefits'];
					$research=$_REQUEST['research'];
					$rewarded=$_REQUEST['rewarded'];
					$Choose_one=$_REQUEST['Choose_one'];
					$reviewid=$_REQUEST['reviewid'];
					$userid=$_REQUEST['userid'];

			/*		$subject=$_REQUEST['r4'];
					$vulnerable=$_REQUEST['r5'];

					$population=$_REQUEST['population'];
					$recruited=$_REQUEST['recruited'];

					$solicited=implode(',', $_REQUEST['chk5']);



				*/
								
					
				
					$purpose=$_REQUEST['purpose'];
					$methodology=$_REQUEST['methodology'];
					$research_subjects=$_REQUEST['research_subjects'];
					$recruited=$_REQUEST['recruited'];
					$drugs=$_REQUEST['drugs'];
					$medical=$_REQUEST['medical'];
					$physical=$_REQUEST['physical'];
					$mental=$_REQUEST['mental'];
					$Electrical=$_REQUEST['Electrical'];
					$photographed=$_REQUEST['photographed'];
					$coercion=$_REQUEST['coercion'];
					$exposed=$_REQUEST['exposed'];
					$benefits=$_REQUEST['benefits'];
					$research=$_REQUEST['research'];
					$rewarded=$_REQUEST['rewarded'];
					$Choose_one=$_REQUEST['Choose_one'];
					echo $reviewid=$_REQUEST['reviewid'];
					echo $userid=$_REQUEST['userid'];


				
					$result=mysql_query("UPDATE `review_faculty` SET `Type_of_review` = '$typeofreview ', `Principal_investigator` = '$Principalinvestigator ', `Title_of_Research_Study_Proposal` = '$study_propos', `Investigator_mailing` = '$inves_mail', `Investigator_telephone` = '$inves_tele ', `Email` = '$email_invester ', `Status` = '$status ', `Sponsorname_and_degree` = '$Sponsor_name ', `Faculty_sponsor_office` = '$fac_office', `Mailing_address` = '$address ', `Telephone` = '$telephone ', `E-mail` = '$inves_mail', `Are_there_co-investigators` = '$coinvestigators', `CO_INVESTIGATORS_names` = '$co_invetname', `Co_investigator_mailing_address` = '$co_invet_mail ', ` Co_investigator_email_address` = '$co_invet_email ', `co_investigator_telephone_number` = '$co_invet_tele', `applicable_categories` = '$study_proposal ', `grant_application` = '$grnt_app ', `IRB_approval` = '$IRB_approval ', ` start_date` = '$start_data ', `end_date` = '$end_data', `study_duration` = '$study_duration ', `esearch_qution` = '	$funding_agency ', `METHODOLOGY` = '$methodology ', `SUBJECTS` = '$research_subjects ', `vulnerable_population` = '$vulnerable_population ', `rationale` = '$rationale ', `number_of_subjects` = '$number_of_subjects ', `recruited` = '$recruited ', ` criteria` = 'criteria ', `drugs` = '$drugs ', `medical` = '$medical ', ` physical_discomfort` = '$physical ', `mental_discomfort` = '$mental', `Electrical _equipment` = '$Electrical', `photographed` = '$photographed ', `coercion` = '$coercion ', `exposed` = '$exposed ', `research_study` = '$research', ` general_knowledge` = 'general_knowledge ', ` rewarded` = '$rewarded ', `Choose one` = '$Choose_one ',`status_submit`= '1' WHERE  rid='$reviewid'");

					if($result)
					{
						echo "<script>alert('save feedback'); window.location='profile.php'</script>";

					}
					else
					{
						echo "<script>alert('error feedback'); window.location='review.php'</script>";
					}
									

?>