<?php
include('../connection.php');
session_start();

$email=$_REQUEST['email'];
$password=$_REQUEST['password'];

$sql=mysql_query("SELECT * FROM `faculty` WHERE  email='$email' AND password='$password'");


if(mysql_affected_rows()>0)
{
	
	$_SESSION['email']=$email;


	//header( "refresh:5; url=profile.php" );
	
	echo "<script>alert('login suessfully'); window.location='profile.php';</script>";
	
}
else
{
	
	echo "<script>alert('login error'); 
	
				window.location='faculty_login.php';</script>";
	
	
}
	



?>