
<?php
include('../connection.php');

$id=$_REQUEST['id'];

$sql=mysql_query("delete from  `sponsorship` where sid='$id'");

if($sql)
{

	echo "<script>alert('delete application'); window.location='view_Sponsorship_Request.php';</script>";

}
else
{
	echo "<script>alert('delete application error'); window.location='view_Sponsorship_Request.php';</script>";
}







?>