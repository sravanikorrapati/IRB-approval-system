<?php

include('header.php');
?>
			<div id="page-wrapper">
			<style>
input[type="submit"] {
    background: rgb(244, 67, 54) none repeat scroll 0 0;
    border: medium none;
    color: white;
    font-size: 1em;
    outline: medium none;
    padding: 10px 0;
    text-align: center;
    transition: all 0.5s ease 0s;
    width: 18% !important;
</style>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Submit Application</h3>
			<form  action="" method="post" class="form-horizontal" enctype="multipart/form-data">
								
								<div class="form-group">
									<label  class="col-sm-2 control-label">Supplementry  name</label>
									<div class="col-sm-8">
										<input  type="text" class="form-control1" name="appname"   value="<?php echo $result[1];?>" required="">
									</div>
								</div>
									<div class="form-group">
									<label  class="col-sm-2 control-label">Supplementry  type</label>
									<div class="col-sm-8">
										<input  type="text" class="form-control1" name="type"  value="<?php echo $result[1];?>" required="">
									</div>
								</div>
									<div class="form-group">
									<label  class="col-sm-2 control-label">Description</label>
									<div class="col-sm-8">
										
										<textarea class="form-control" rows="5" id="comment" name="description" required="" ></textarea>
									</div>
								</div>
								<div class="form-group">
									<label  class="col-sm-2 control-label">Upload materials</label>
									<div class="col-sm-8">
										
										<input type="file" name="image" required="" />
									</div>
								</div>
							
								
								<div class="col-sm-8 col-sm-offset-2">
								<input type="submit" class="btn-success btn" value="Submit" name="s1">
								
								</div>
						
					</form>
					
					
				</div>
			</div>
			
				
			</div>
			<?php
			
			if(isset($_REQUEST['s1']))
			{
				include('../connection.php');
				
				$file=$_FILES["image"]["tmp_name"];
				$description="file/".$_FILES["image"]["name"];
				if(move_uploaded_file($file,$description))
				{
					
				  $image=$_FILES["image"]["name"];
					
				}
				$name=$_REQUEST['appname'];
				$description=$_REQUEST['description'];
				$type=$_REQUEST['type'];
				 $email=$_SESSION['email'];

				$data=mysql_query("SELECT * FROM `faculty` WHERE email='$email'");
					
					$row=mysql_fetch_array($data);
					//print_r($row);
					$fid=$row[0];
					$sql=mysql_query("INSERT INTO `materials` (
					`id` ,`name` ,`type` ,`description` ,`file` ,`status`,`fid`)VALUES (NULL , '$name', '$type', '$description', '$image', 0,'$fid')");

			
				
				if($sql)
				{
					
					echo "<script>alert('submit materials'); window.location='profile.php';</script>";
					
				}
				else
					
					{
						
					echo "<script>alert('submit error'); window.location='profile.php';</script>";	
						
					}
				
			
				
				
				
				
				
				
				
				
			}
			?>
		
		<?php
		include('footer.php');?>
		