
<style>
.main-content.main-content5 > div {
    text-align: center;
}
</style>

<?php

include('header.php');
?>
			<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Hi <?php echo $result['firstname'];?> welcome to IRB Home page</h3>
					<div class="graph_box">
						<div class="col-md-4">
							<div class="dropdown">
							<a href="Apply_for_standard_review.php"><button class="btn btn-primary dropdown-toggle" type="button">Apply for standard review</button></a>
							<!-- <ul class="dropdown-menu">
							<li><a href="#">Apply For Standard review</a></li>
							<li><a href="#">Apply For expedited review</a></li>
							<li><a href="#">Apply For exempted review</a></li>
							</ul> -->
						</div> 
						</div>
						<div class="col-md-4">
							<a href ="review.php"><button class="btn btn-primary" type="button" >Submit application
							</button></a>
						</div>
						<div class="col-md-4">
							<a href="supplymnet.php"><button class="btn btn-primary" type="button"  >Upload supplementry materials
							</button></a>

						</div>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="container">
					<br/>
					<br/>
						<div class="col-md-4">
						
								
								<a href="view_Sponsorship_Request.php"><button class="btn btn-primary" type="button"> view Sponsorship Request
							</button></a>
						</div>
						<div class="col-md-4">
								<a href="view_faculty_form.php"><button class="btn btn-primary" type="button" >View submitted Application
							</button></a>
							</div>
								
						
							<div class="col-md-4">
								
										<a href="sponsoring_candidates.php"><button class="btn btn-primary" type="button" >sponsoring candidates
							</button></a>
								</div>
							
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
		</div>
		<?php
		include('footer.php');?>
		