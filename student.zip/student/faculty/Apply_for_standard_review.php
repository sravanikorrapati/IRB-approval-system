<?php
include('header.php');
?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css"/>
<script src="multi_step_form.js"></script>
<div class="content">
<!-- multistep form -->
<div  class="main">
<form class="regform" action="Apply_for_standard_review_insert.php" method ="get">
	<!-- progressbar -->
	<ul id="progressbar">
		<li class="active">step 1</li>
		<li>step 2</li>
		<li>step 3</li>
	</ul>
	
	<!-- fieldsets -->
										<fieldset id="first">
										<h2 class="title">Step 1</h2>
										<div class="form-group">
										<label for="inputEmail">Type of review*</label>
											<div class="radio">
											<label><input type="radio" name="r1" value="standard application">standard application</label>
											</div>
										<div class="radio">
										<label><input type="radio" name="r1" value="Exempted from standard application">Exempted from standard application</label>
										</div>
										<div class="radio">
										<label><input type="radio" name="r1" value="Expedited application">Expedited application</label>
										</div>
										</div>
										<div class="form-group">
										<label>Principal investigator *</label>
										<input type="text" class="form-control" id="usr" name="Principal_ans" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Title of Research Study Proposal: *</label>
										<input type="text" class="form-control" id="usr" name="study_propos" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Investigator mailing address: *</label>
										<input type="text" class="form-control" id="usr" name="inves_mail" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Investigator telephone *</label>
										<input type="text" class="form-control" id="usr" name="inves_tele" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Email*</label>
										<br/>
										<i>I have examined this completed form and I am satisfied with the adequacy of the proposed research design and the measures proposed for the protection of human subjects.  I agree to accept joint responsibility for the conduct of this study and the investigators’ compliance with IRB policies.</i>

										<input type="text" class="form-control" id="usr" name="email_invester" placeholder="Enter Answer">
										</div>
										<div class="form-group">
											<label for="sel1">Status*</label>
											<input type="radio" name="student" value="student">&nbsp;&nbsp;&nbsp;student (Must have a faculty sponsor’s signature) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="student" value="faculty">&nbsp;&nbsp;&nbsp;Faculty&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <input type="radio" name="student" value="other">&nbsp;&nbsp;&nbsp;Other
										
										
										</div>
										<div class="form-group">
										<label>Sponsor name and degree*</label>
										<input type="text" class="form-control" id="usr" name="Sponsor_name" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Faculty sponsor’s signature</label>
										<label>Faculty sponsor’s office*</label>
										<input type="text" class="form-control" id="usr" name="fac_office" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Mailing address*</label>
										<input type="text" class="form-control" id="usr" name="address" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Telephone</label>
										<input type="text" class="form-control" id="usr" name="telephone" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>E-mail</label>
										<input type="text" class="form-control" id="usr" name="email" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label for="sel1">Are there co-investigators? </label>
										<select class="form-control" id="sel1" name="co-investigators">
										<option>choose</option>
										<option value="yes">yes</option>
										<option value="no">no</option>
										</select>
									
									</div>
										<input type="button" name="next" class="next_btn" value="Next" />
										<!-- <input type="submit" name="s1" class="submit_btn" value="save" /> -->
										<BR/>	<BR/>	<BR/>
	
	</fieldset>
	<fieldset>

		<h2 class="title">Step-2</h2>
									<div class="form-group">
									Co-Investigator (typed):<BR/>
									<label>CO INVESTIGATORS names</label>
									<input type="text" class="form-control" id="usr" name="co_invet" placeholder="Enter Answer">
									</div>
									<div class="form-group">
									<label>Co investigator mailing address</label>
									<input type="text" class="form-control" id="usr" name="co_invet_mail" placeholder="Enter Answer">
									</div>
									<div class="form-group">
									<label>Co investigator email address</label>
									<input type="text" class="form-control" id="usr" name="co_invet_email" placeholder="Enter Answer"/>
									</div>

									<div class="form-group">
									<label>co investigator telephone number</label>
									<input type="text" class="form-control" id="usr" name="co_invet_tele" placeholder="Enter Answer"/>
									</div>
									<div class="form-group">
									<label>. Please check applicable categories.  This research study proposal is:  </label>
									<div class="form-group">
									<input type="checkbox" name="chk1[]" value="A new grant/contract">A new grant/contract
									</div>
									<div class="form-group">
									<input type="checkbox"  name="chk1[]" value="A dissertation or thesis">A dissertation or thesis
									</div>
									<div class="form-group">
									<input type="checkbox" name="chk1[]" value="An amendment to an existing study">An amendment to an existing study
									</div>
									<div class="form-group">
									<input type="checkbox" name="chk1[] value="A graduate research proposal">A graduate research proposal
									</div>
									<div class="form-group">
									<input type="checkbox"   name="chk1[]" value="A graduate research proposal">An addendum to an existing study
									</div>
									<div class="form-group">
									<input type="checkbox"  name="chk1[]" value="A graduate research proposal"> An independent study
									</div>
									<div class="form-group">
									<input type="checkbox" value="A class project" name="chk1[]"> A class project
									</div>
									<div class="form-group">
									<input type="checkbox"  name="chk1[]" value="An undergraduate research proposal"/> An undergraduate research proposal
									</div>
									</div>
									<div class="form-group">
									<label>If the proposal is a grant application, indicate the funding agency</label>
									<input type="text" class="form-control" id="usr" name="grnt_app" placeholder="Enter Answer">
									</div>
									<div class="form-group">
										<label for="inputEmail">Is notification of IRB approval required by the granting agency</label><BR/>
										<input type="radio" name="r2" value="yes">yes<BR/>
										<input type="radio" name="r2" value="no">No<BR/>
										<input type="radio" name="r2" value="Expedited application">Expedited application
									</div>
									<div class="form-group">
									<label>If the proposal is a grant application, indicate the funding agency</label>
									<input type="text" class="form-control" id="usr" name="grnt_app" placeholder="Enter Answer">
									</div>
									<div class="form-group">
									<label>Data gathering start date:</label>
									<input type="text" class="form-control" id="usr" name="start_date" placeholder="dd/MM/YY"/>
									</div>
									<div class="form-group">
										<label>Data gathering end date:</label>
										<input type="text" class="form-control" id="usr" name="end_date" placeholder="dd/MM/YY">
									</div>
									<div class="form-group">
										<label for="inputEmail">What is the projected study duration?</label><BR/>
										<input type="radio" name="r3" value="Fewer than 13 months from application date">Fewer than 13 months from application date<BR/>
										<input type="radio" name="r3" value="More than 13 months from application date">More than 13 months from application date<BR/>
									</div>
		<input type="button" name="previous" class="pre_btn" value="Previous" />
		<input type="button" name="next" class="next_btn" value="Next" />
		<BR/><BR/><BR/>
	</fieldset>
	<fieldset>
			<h2 class="title">Step 3</h2>
			<div class="form-group">
				<label for="inputEmail">Purpose: What is the purpose of the research? State the hypothesis or research question</label>
				<input type="text" class="form-control" id="usr" name="purpose" placeholder="Enter Answer">
			</div>
			<div class="form-group">
			<label for="inputEmail">Methodology: How will the research be conducted?</label>
				<input type="text" class="form-control" id="usr" name="methodology" placeholder="Enter Answer">
			</div>
			<div class="form-group">
				<label for="inputEmail">SUBJECTS: Who will be the research subjects? Please select one.</label>
				<div class="radio">
				<label><input type="radio" name="r4" value="Research subjects will be selected from adult members of the population at large." >Research subjects will be selected from adult members of the population at large.</label>
				</div>
				<div class="radio">
				<label><input type="radio" name="r4" value="Research subjects will be selected from vulnerable populations.">Research subjects will be selected from vulnerable populations.</label>
				</div>
				<div class="radio">
				<label><input type="radio" name="r4" value="Research subjects will be selected from de-identified data.">Research subjects will be selected from de-identified data.</label>
				</div>
		</div>

		<div class="form-group">
			<label>If research subjects will be selected from a vulnerable population, please select all that apply:</label>
			<input type="checkbox" name="chk91[]" value="Minors under age of 18"> Minors under age of 18<br/>
			<input type="checkbox" name="chk91[]" value="Senior Citizens (over 65)">Senior Citizens (over 65)<br/>
			<input type="checkbox" name="chk91[]" value="Terminally Ill"> Terminally Ill<br/>
			<input type="checkbox" name="chk91[]" value="Students"> Students<bt/>
			<input type="checkbox" name="chk91[]" value="Prisoners"> Prisoners<br/>
			<input type="checkbox"  name="chk91[]"  value="Cognitively Impaired"> Cognitively Impaired<br/>
			<input type="checkbox" name="chk91[]"  value="Non-English Speakers"> Non-English Speakers<br/>
			<input type="checkbox" name="chk91[]" value="Mentally/Physically Disabled"> Mentally/Physically Disabled<br/>
			<input type="checkbox"  name="chk91[]" value="Pregnant Women"> Pregnant Women<br/>
			<input type="checkbox" name="chk91[]" value="Institutional Residents"> Institutional Residents<br/>
			<input type="checkbox" name="chk91[]" value="Employees"> Employees<br/>
			<input type="checkbox" name="chk91[]" value="Economically Disadvantaged"> Economically Disadvantaged<br/>
		</div>
		<div class="form-group">
		<label>State the rationale for using vulnerable populations. What safeguards will be used to protect members of a vulnerable population?</label>
		<input type="text" class="form-control" id="usr" name="population" placeholder="Enter Answer">
		</div>
		<div class="form-group">
		<label>What is the approximate total number of subjects to be recruited?</label>
		<input type="text" class="form-control" id="usr" name="recruited" placeholder="Enter Answer">
		</div>
		<div class="form-group">
		<label>How will the subjects be recruited/solicited? Please check all that apply.</label>
		<input type="checkbox" name="chk5[]" value="A class project"> Advertisements<br/>
		<input type="checkbox" name="chk5[]" value="A class project">Letters<br/>
		<input type="checkbox" name="chk5[]" value="A class project"> Random Calls<br/>
		<input type="checkbox" name="chk5[]" value="A class project"> Notices<br/>
		<input type="checkbox" name="chk5[]" value="A class project"> Direct Solicitation<br/>
		</div>
			<div class="form-group">
			<table border="1">
			<tr>
				<th>Risk Criteria assessment</th>
				<th>choose one</th>
		</tr>
		
		<tr>
		<td>
		 With respect to any of the above criteria, subjects are at risk.></td>
		 <td><input type="checkbox" name="yes[]" value="A class project">yes <input type="checkbox" name="yes[]" value="no">No</td>
		 </tr>
		 <tr>
		 <td>Experimental drugs will be used.</td>
		 	<td><input type="checkbox" name="yes1[]" value="A class project">yes <input type="checkbox" name="yes1[]" value="no">No<br/></td>
		 </tr>
		 <tr>
			 <td>
				 Potential for a medical problem exists.</td>
				 <td><input type="checkbox" name="yes2[]" value="A class project">yes <input type="checkbox" name="yes2[]" value="no">No</td>
		 </tr>
		  <tr>
			 <td>
			 Subjects may experience physical discomfort greater than in everyday life.</td>
			 <td><input type="checkbox" name="yes3[]" value="A class project">yes <input type="checkbox" name="yes3[]" value="no">No</td>
		 </tr>
		 <tr>
			 <td>
			 Subjects may experience mental discomfort greater than in everyday life.</td>
			 <td><input type="checkbox" name="yes5[]" value="A class project">yes <input type="checkbox" name="yes5[]" value="no">No</td>
		 </tr>
		 <tr>
			 <td>
			 Electrical equipment will be used..</td>
			 <td><input type="checkbox" name="yes6[]" value="A class project">yes <input type="checkbox" name="yes6[]" value="no">No</td>
		 </tr>
		 <tr>
			 <td>Subjects will be tape recorded, photographed, or videotaped.</td>
			 <td><input type="checkbox" name="yes7[]" value="A class project">yes <input type="checkbox" name="yes7[]" value="no">No</td>
		 </tr>
		 </table>
		 	<div class="form-group">
			<label for="inputEmail">Does any part of this activity have the potential for coercion of the subject?</label>
			<div class="radio">
			<label><input type="radio" name="r13" value="yes">YES</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r13" value="no">No</label>
			</div>
			</div>

			<div class="form-group">
				<label for="inputEmail">Are the subjects exposed to deception?</label>
					<div class="radio">
					<label><input type="radio" name="r14" value="yes">YES</label>
					</div>
					<div class="radio">
					<label><input type="radio" name="r14" value="no">No</label>
					</div>
			</div>
			<div class="form-group">
				<label for="inputEmail">What possible benefits could the subject derive from participation in the proposed research study?</label>
				<input type="text" class="form-control" id="usr" name="benefits" placeholder="Enter Answer">
			</div>
			<div class="form-group">
				<label for="inputEmail">What contributions to general knowledge in the field of inquiry or possible benefits could be derived from the research?</label>
				<input type="text" class="form-control" id="usr" name="eresarch" placeholder="Enter Answer">
			</div>
			<div class="form-group">
				<label for="inputEmail">If subjects will be rewarded or compensated, state the amount, types, and timetable for compensation. If subjects are recruited from Gannon University classes, state whether students are receiving course credit (regular or extra credit) and state alternatives offered to students who do not wish to participate.</label>
				<div class="radio">
					<label><input type="radio" name="r15" value="yes">YES</label>
				</div>
				<div class="radio">
					<label><input type="radio" name="r15" value="no">No</label>
				</div>
				<div class="radio">
					<label><input type="radio" name="r15" value="other">other</label>
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail">Choose one</label>
					<div class="radio">
						<label><input type="radio" name="r18" value="The research involves no more than minimal risk.">The research involves no more than minimal risk.</label>
					</div>
					<div class="radio">
						<label><input type="radio" name="r18" value="The research involves more than minimal risk">The research involves more than minimal risk.</label>
					</div>
			</div>
			<div class="form-group">
					<label>What type of consent will be used?  Check all that apply.</label>
					<input type="checkbox" name="chk12[]" value="Written_Consent"> Written Consent<br/>
					<input type="checkbox" name="chk12[]" value="Parental_Consent">Parental Consent<br/>
					<input type="checkbox" name="chk12[]" value="Information_Sheet"> Information  Sheet<br/>
					<input type="checkbox" name="chk12[]" value="oral_Consent"> oral Consent<br/>
					<input type="checkbox" name="chk12[]" value="Assent_for_Minors">Assent for Minors<br/>
					<input type="checkbox" name="chk12[]" value="Waiver"> Waiver<br/>
					
			</div>
			<div class="form-group">
				<label>Describe how and by whom the consent forms and other material will be distributed and collected to protect confidentiality and subject anonymity.</label>
				<input type="text" class="form-control" id="usr" name="subject_anonymity" placeholder="Enter Answer">
			</div>
				<div class="form-group">
				<label for="inputEmail">Are subjects informed that they may withdraw at any time without penalty</label>
					<div class="radio">
						<label><input type="radio" name="informed" value="yes">yes.</label>
					</div>
					<div class="radio">
						<label><input type="radio" name="informed" value="no">no</label>
					</div>
			</div>
		<div class="form-group">
		<label>If not, describe the rationale for this decision.</label>
			<input type="text" class="form-control" id="usr" name="rationale_decision" placeholder="Enter Answer">
		</div>	
		<div class="form-group">
		<label>If a written consent will not be used, describe the rationale for this decision.</label>
			<input type="text" class="form-control" id="usr" name="describe_the_rationale " placeholder="Enter Answer">
		</div>

		<div class="form-group">
			<label>If oral consent will be used, describe how consent will be documented.  Provide script for oral consent.</label>
			<input type="text" class="form-control" id="usr" name="oral_consent" placeholder="Enter Answer">
		</div>

		<div class="form-group">
			<label>If minors will be participating and a parental consent form will not be used, describe the rationale</label>
			<input type="text" class="form-control" id="usr" name="describe_the_rationale" placeholder="Enter Answer">
		</div>
		<div class="form-group">
			<label>If minors aged 7 to 17 will be participating and an assent form for minors will not be used, describe the rationale.</label>
			<input type="text" class="form-control" id="usr" name="minors_aged" placeholder="Enter Answer">
		</div>
		<div class="form-group">
			<label>If the primary investigator is requesting that consent be waived, describe the rationale.</label>
			<input type="text" class="form-control" id="usr" name="primary_investigator" placeholder="Enter Answer">
		</div>
		<div class="form-group">
		<table border="1">
		<tr>
			<td colspan="3">checklist of required elements contained in an informed consent document or script for a study that involves no more than minimal risk</td>
		</tr>
		<tr>
			<td>R01. Statement that the study involves research.</td>
			<td><input type="radio" name="sa" value="yes">Yes</td>
			<td><input type="radio" name="sa" value="no">no</td>
		</tr>
		<tr>
			<td> R02. Title of the study</td>
			<td><input type="radio" name="ch" value="yes">Yes</td>
			<td><input type="radio" name="ch" value="no">no</td>
		</tr>
		<tr>
			<td>R03. Name of principal investigator/primary researcher.</td>
			<td><input type="radio" name="in" value="yes">Yes</td>
			<td><input type="radio" name="in" value="no">no</td>
		</tr>
		<tr>
			<td>R04. Statement that participation is voluntary.</td>
			<td><input type="radio" name="sh" value="yes">Yes</td>
			<td><input type="radio" name="sh" value="no">no</td>
		</tr>
	
			<tr>
			<td>R05. Explanation of purposes of study.</td>
			<td><input type="radio" name="ra" value="yes">Yes</td>
			<td><input type="radio" name="ra" value="no">no</td>
		</tr>

		<tr>
			<td>R06. Accounting of the expected duration of subject’s participation</td>
			<td><input type="radio" name="ha" value="yes">Yes</td>
			<td><input type="radio" name="ha" value="no">no</td>
		</tr>
		
		<tr>
			<td>R07. Description of procedures to be followed.</td>
			<td><input type="radio" name="ga" value="yes">Yes</td>
			<td><input type="radio" name="ga" value="no">no</td>
		</tr>
		<tr>
			<td>R08. Explanation of extent to which confidentiality will be maintained.</td>
			<td><input type="radio" name="rh" value="yes">Yes</td>
			<td><input type="radio" name="rh" value="no">no</td>
		</tr>
		<tr>
			<td>R09.Identification of benefits to subject or to others from the research.</td>
			<td><input type="radio" name="r15" value="yes">Yes</td>
			<td><input type="radio" name="r15" value="no">no</td>
		</tr>
		<tr>
			<td> R10. Identification of any procedures which are experimental.</td>
			<td><input type="radio" name="r16" value="yes">Yes</td>
			<td><input type="radio" name="r16" value="no">no</td>
		</tr>
			<tr>
			<td>R11. Description of possible physical omentar l risk or discomfort.</td>
			<td><input type="radio" name="r17" value="yes">Yes</td>
			<td><input type="radio" name="r17" value="no">no</td>
		</tr>
		<tr>
			<td>R12. Statement that refusal to participate will involve no penalty.</td>
			<td><input type="radio" name="r18" value="yes">Yes</td>
			<td><input type="radio" name="r18" value="no">no</td>
		</tr>
		<tr>
			<td>R13. Name contact person for questions about the study.</td>
			<td><input type="radio" name="r19" value="yes">Yes</td>
			<td><input type="radio" name="r19" value="no">no</td>
		</tr>
		<tr>
			<td>R14. Name contact person for questions about the subjects’ rights.</td>
			<td><input type="radio" name="r20" value="yes">Yes</td>
			<td><input type="radio" name="r20" value="no">no</td>
		</tr>
		<tr>
			<td>R15. Notification if subjects will be recorded or photographed.</td>
			<td><input type="radio" name="r21" value="yes">Yes</td>
			<td><input type="radio" name="r21" value="no">no</td>
		</tr>
		<tr>
			<td>R16. Description of procedures by which subjects may discontinue participation.</td>
			<td><input type="radio" name="r22" value="yes">Yes</td>
			<td><input type="radio" name="r22" value="no">no</td>
		</tr>
		
		<tr>
			<td>R17. Informed consent documents have a Reading Level of ≤8.0 by Microsoft Word calculation.</td>
			<td><input type="radio" name="r23" value="yes">Yes</td>
			<td><input type="radio" name="r23" value="no">no</td>
		</tr>

		</table>
	</div>
		<div class="form-group">
			<label>Explain any “No” answers checked for R01-R17 in this space:</label>
			<input type="text" class="form-control" id="usr" name="checked" placeholder="Here">
	</div>
	<div class="form-group">
					<label>Data collection methods.  Please check all that apply.  Attach copies of tools and study instruments, including interview script, if used.</label>
					<input type="checkbox" name="chk5[]" value=" Questionnaire or Survey"> Questionnaire or Survey <br/>
					<input type="checkbox" name="chk51[]" value="Intervention">Intervention<br/>
					<input type="checkbox" name="chk51[]" value="Interview">Interview<br/>
					<input type="checkbox" name="chk51[]" value="Focus Groups">Focus Groups<br/>
					<input type="checkbox" name="chk51[]" value="Observation">Observation<br/>
					<input type="checkbox" name="chk51[]" value="Testing/Evaluation">Testing/Evaluation<br/>
					
					<input type="checkbox" name="chk51[]" value="Video or Audio Taping">Video or Audio Taping<br/>
					<input type="checkbox" name="chk51[]" value="Instruction/Curriculum">Instruction/Curriculum<br/>
					<input type="checkbox" name="chk51[]" value="Computer Collected Task Data">Computer Collected Task Data<br/>
					<input type="checkbox" name="chk51[]" value="Physical Tasks">Physical Tasks<br/>
					<input type="checkbox" name="chk51[]" value="Archival Data">Archival Data<br/>
					<input type="checkbox" name="chk51[]" value="Other">Other<br/>
	</div>
	<div class="form-group">

		<label>(All options here are check boxes and upload is for attaching the docs related to any of the above options which ever checked in while filling the form)</label>
		<table>
			<tr>
				<td>Will the data be collected with identifiers?</td>
				<td><input type="radio" name="r24" value="yes">Yes</td>
				<td><input type="radio" name="r24" value="no">no</td>
			</tr>
			<tr>
				<td>Will the data retain identifiers for analysis? </td>
				<td><input type="radio" name="r25" value="yes">Yes</td>
				<td><input type="radio" name="r25" value="no">no</td>
			</tr>
			<tr>
				<td> Will the data retain identifiers for reporting? </td>
				<td><input type="radio" name="r27" value="yes">Yes</td>
				<td><input type="radio" name="r27" value="no">no</td>
			</tr>
		</table>
	</div>
	<div class="form-group">
		<label>Describe if or how research findings will be disseminated to subjects.  </label>
			<input type="text" class="form-control" id="usr" name="disseminated" placeholder="Enter Answer">
	</div>
	<div class="form-group">
			Describe provisions of maintaining security of the data.  
			Note: Data should be secured while collection is in progress and when stored.  Provide a plan for data storage for at least 3 years.
			<label>(a) storage arrangements for the consent forms and other material</label>
			<input type="text" class="form-control" id="usr" name="arrangements" placeholder="Enter Answer"> 
	</div>
	<div class="form-group">
			<label>(b) an accounting of the persons who will have access to identified data </label>
			<input type="text" class="form-control" id="usr" name="accounting" placeholder="Here">
	</div>
	<div class="form-group">
			<label>(c) schedule and methods for de-identification of data, if appropriate</label>
			<input type="text" class="form-control" id="usr" name="de-identification" placeholder="Here">
	</div>
		<div class="form-group">
			<label>(d) schedule and methods for long-term storage of raw data </label>
			<input type="text" class="form-control" id="usr" name="long-term-storage" placeholder="Here">
		</div>
		<div class="form-group">
			<label>(e) schedule and methods for eventual destruction of data.</label>
			<input type="text" class="form-control" id="usr" name="eventual" placeholder="Here">
		</div>

		



		<input type="hidden" name="userid" value="<?php echo $result[0];?>"/>
				<input type="button" class="pre_btn" value="Previous" />
				<input type="submit" name="s1" class="submit_btn" value="Submit" /><BR/><BR/><BR/>
			</fieldset>
</form>
</div>
</div>
</div>	

 

				 

	<?php
	include('footer.php');

	?>