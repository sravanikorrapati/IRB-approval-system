<?php
include('header.php');
?>
<br/>
<br/

<div class="container">    
  <div class="row">
    <div class="col-sm-2">
    </div>
    <div class="col-sm-8"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Send any query to admin </div>
        <div class="panel-body">
          <div class="form-group">
<form action="" method="post">
              <label for="usr">Name:</label> 
              <input type="text" class="form-control" id="usr" name="name" required="">
          </div>
          <div class="form-group">
              <label for="pwd">Email:</label>
              <input type="email" class="form-control" id="pwd" name="email" required="">
          </div>
           <div class="form-group">
              <label for="pwd">Question:</label>
              <input type="text" class="form-control" id="pwd" name="question" required="">
          </div>
             <div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg" name="q1">Submit</button>

          </div>
</form>
           
        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
    <div class="col-sm-2"> 
     
    </div>
  </div>
</div><br>



<footer class="container-fluid text-center">
  <p> Copyright</p>  
  
</footer>

</body>
</html>

<?php
if(isset($_REQUEST['q1']))
{
include('connection.php');

$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$question=$_REQUEST['question'];

$sql=mysql_query("INSERT INTO `feedback` (
`id` ,
`name` ,
`email` ,
`question`
)
VALUES (
NULL , '$name', '$email', '$question'
)");

if($sql)
{
  echo "<script>alert('succesfully insert'); window.location='profile.php'</script>";

}
else
{
  echo "<script>alert('error insert'); window.location='profile.php'</script>";

}

}
?>
<?php
include('footer.php');
?>

