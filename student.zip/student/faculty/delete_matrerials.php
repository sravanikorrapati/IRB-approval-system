<?php
include('../connection.php');
$id=$_REQUEST['id'];

$sql=mysql_query("DELETE FROM `student`.`materials` WHERE `materials`.`id`='$id'");

if($sql)
{


echo "<script>alert('delete'); window.location='view uploaded materials.php'</script>";

}
else
{
	echo "<script>alert('error'); window.location='view uploaded materials.php'</script>";

}






?>