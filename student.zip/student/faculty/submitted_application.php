<?php
include('header.php');

?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Student information</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
				<table class="table">
						  <thead>
							<tr>
							  <th>App id</th>
							  <th>Name</th>
							  <th>Type</th>
							  <th>Description</th>
							  <th>status</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
									 $email=$_SESSION['email'];

									 $data=mysql_query("select * from faculty where email='$email'");
									 $row=mysql_fetch_array($data);
									 //print_r($row);
									 $uid=$row[0];

								$sql="SELECT * FROM `application` where userid='$uid'";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{
									//print_r($result);
								?>
							<tr class="active">
							  <th scope="row"><?php echo $result[0];  ?></th>
							  <td><?php echo $result[1];?></td>
							  <td><?php echo $result[2];?></td>
							  <td><?php echo $result[3];?></td>
							  <td><?php
								if($result[4]==0)
									{
									echo "pandding"; 
									}
								else
									{
									echo "Approve"; 
									}

								?></td> 
							  
							</tr>																						<?php		
								}
								?>
						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>
					   












<?php

include('footer.php');
?>