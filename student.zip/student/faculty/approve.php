<?php


include('../connection.php');


$appid=$_REQUEST['id'];

$sql="update `sponsorship` set requeststatus=1 where sid='$appid'";
$res=mysql_query($sql);

if($res)
{


	echo "<script>alert('Accept request'); window.location='view_Sponsorship_Request.php'</script>";
}
else
{

	echo "<script>alert('Accept request error'); window.location='view_Sponsorship_Request.php'</script>";
}





?>