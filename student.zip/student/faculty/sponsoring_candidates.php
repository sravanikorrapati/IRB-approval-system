<?php
include('header.php');
?>
<?php
 $idfac=$result[0];

?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1"> view  all   Sponsorship Request</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
				<table class="table">
						  <thead>
							<tr>
							  <th>id</th>
							  <th> Student name</th>
							  <th>question</th>
							  <th>description</th>
							  <th>Faculty status</th>
							  <th> IRB status</th>
							  <th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
								$sql="SELECT * FROM `sponsorship` where fid='$idfac' ";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{
									//print_r($result);
								?>
							<tr class="active">
							  <th scope="row"><?php echo $result[0];?></th>
							  <td><?php $fname= $result['userid'];

							  			$sql=mysql_query("select * from user where id='$fname'");
							  			$row=mysql_fetch_array($sql);
							  			echo $row[1];

							  ?></td>
							 
							  <td><?php echo $result['question'];?></td>
							  <td><?php echo $result['description'];?></td>
							   <td><?php  $result['requeststatus'];
							   		if($result['requeststatus']==0)
							   		{

							   			echo "<a href='approve.php?id=$result[0]' title='click to accept status'>accept Request</a>";


							   		}
							   		else
							   		{
							   			echo "approve ";

							   		}

							   		?></td>
							   		<td><?php  $result['appstatus'];
							   		if($result['appstatus']==0)
							   		{

							   			echo "panding";


							   		}
							   		else
							   		{
							   			echo "approve ";

							   		}

							   		?></td>



							  <!-- <td><a href="student_edit.php?id=<?php echo $result[0];?>">edit</a></td> -->
							  <td><a href="sponsorship_delete.php?id=<?php echo $result[0];?>">Delete</a></td>
							  
							</tr>																						<?php		
								}
								?>
						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>
					   












<?php

include('footer.php');
?>