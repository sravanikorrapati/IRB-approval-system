<?php
include('header.php');
?>
<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">uplaod matrails</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						  <thead>
							<tr>
								  <th>Id</th>
								  <th>name</th>
								  <th>Type</th>
								  <th>description</th>
								  <th>file</th>
								  <th>Delete</th>
								  
							</tr>
						  </thead>
						  <tbody>
								<?php
									$fid=$result[0];
									$sql="SELECT * FROM `materials` WHERE fid ='$fid'";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
									{
										// /print_r($result);

								?>
							<tr class="active">
							  <td><?php echo $result[0];?></td>
							  <td><?php echo $result['name'];?></td>
							  <td><?php echo $result['type'];?></td> 
							  <td><?php echo $result['description'];?></td>
							  <td><img src="file/<?php echo $result['file'];?>" height="50px" width="50"/></td>
							  <td><a href="delete_matrerials.php?id=<?php echo $result[0];?>">delete</a></td>
							<?php
						}
						?>

						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>		


   
<?php
include('footer.php');
?>
