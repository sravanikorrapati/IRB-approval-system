<?php
include('header.php');
?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">view  submit application</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						 	<thead>
							<tr>
								<th>Review Id</th>
								<th>student status</th>
								<th>Type_of_review</th>
								<th>Principal investigator</th>
								<th>view more</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
								$userid=$result[0];
									$sql="SELECT * FROM `review_faculty` where faculty_id='$userid' and status_submit=0";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
								<td><?php echo $result[0];?></td>
								
								<td><?php echo $result['Status'];?></td>
								<td><?php echo $result['Principal_investigator'];?></td>
								<td><?php echo $result['Type_of_review'];?></td>
								<td><a href="view_submit_app.php?id=<?php echo $result[0];?>">view more </a></td>
									
							</tr>	
							<?php		
								}
								?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			 </div>			   
<?php
include('footer.php');
?>