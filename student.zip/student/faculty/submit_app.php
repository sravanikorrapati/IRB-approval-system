<?php

include('header.php');
?>
			<div id="page-wrapper">
			<style>
input[type="submit"] {
    background: rgb(244, 67, 54) none repeat scroll 0 0;
    border: medium none;
    color: white;
    font-size: 1em;
    outline: medium none;
    padding: 10px 0;
    text-align: center;
    transition: all 0.5s ease 0s;
    width: 18% !important;
</style>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Submit Application</h3>
			<form  action="" method="post" class="form-horizontal">
								
								<div class="form-group">
									<label  class="col-sm-2 control-label">Application name</label>
									<div class="col-sm-8">
										<input  type="text" class="form-control1" name="appname"  value="<?php echo $result[1];?>">
									</div>
								</div>
									<div class="form-group">
									<label  class="col-sm-2 control-label">Application type</label>
									<div class="col-sm-8">
										<input  type="text" class="form-control1" name="type"  value="<?php echo $result[1];?>">
									</div>
								</div>
									<div class="form-group">
									<label  class="col-sm-2 control-label">Description</label>
									<div class="col-sm-8">
										
										<textarea class="form-control" rows="5" id="comment" name="description"></textarea>
									</div>
								</div>
							
								
								<div class="col-sm-8 col-sm-offset-2">
								  <input type="submit" class="btn-success btn" value="Submit" name="s1">
								</div>
						
					</form>
					
					
				</div>
			</div>
			
				
			</div>
			<?php
			
			if(isset($_REQUEST['s1']))
			{
				include('../connection.php');
				$name=$_REQUEST['appname'];
				$description=$_REQUEST['description'];
				$type=$_REQUEST['type'];
				
				$userid=$_SESSION['email'];
				
				$sql=mysql_query("select * from faculty where email='$userid'");
				$result=mysql_fetch_array($sql);
				$userid=$result[0];
			
			
				$sql=mysql_query("INSERT INTO `application` (
				`appid` ,
				`name` ,
				`type` ,
				`description` ,
				`status`,
				`userid`)VALUES (
				NULL , '$name', '$type', '$description', 0,'$userid')");
				
				
				if($sql)
				{
					
					echo "<script>alert('submit application'); window.location='profile.php';</script>";
					
				}
				else
					
					{
						
					echo "<script>alert('submit error'); window.location='profile.php';</script>";	
						
					}
				
			
				
				
				
				
				
				
				
				
			}
			?>
		
		<?php
		include('footer.php');?>
		