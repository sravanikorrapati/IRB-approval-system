<?php

include('header.php');
include('../connection.php');
?>
<div id="page-wrapper">
	<div class="container">    
		<div class="row">
			<div class="col-sm-2">
					<?php
					$id=$_REQUEST['id'];
					$review_id=$_REQUEST['review_id'];
					$res=mysql_query("select * from user where id='$id'");

						$ros=mysql_fetch_array($res);
						?>
			</div>
    <div class="col-sm-8"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Send Sponsorship Request </div>
       	 <div class="panel-body">
			<form action="" method="post">
			 <div class="form-group">
				<label for="sel1">Student:</label>
				<input type="text" class="form-control" id="pwd" name="username" required="" value="<?php echo $ros['firstname'];?>" readonly="">
				<input type="hidden" class="form-control" id="pwd" name="userid" required="" value="<?php echo $ros['id'];?>">
			</div>
				<div class="form-group">
					<label for="comment">Description:</label>
					<textarea class="form-control" rows="5" id="comment" name="description"></textarea>
				</div>
             <div class="form-group">
           		 <button type="submit" class="btn btn-primary btn-lg" name="q1">Submit</button>
          </div>
</form>
           
        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
    <div class="col-sm-2"> 
    </div>
 </div>
			<?php
		if(isset($_REQUEST['q1']))
		{
			$userid=$_REQUEST['userid'];
			$description=$_REQUEST['description'];
			$status=0;
			$review_id=$_REQUEST['review_id'];
		
		$result=mysql_query("INSERT INTO `sent_error_student` (
`error_id` ,`user_id` ,`description` ,`status`,`review_id`)VALUES (NULL , '$userid', '$description','$status','$review_id');

");


		//print_r($result);
	
		
		if($result)
		{

			

			echo "<script> alert('submit  error report'); window.location='profile.php';</script>";

		}
		else
		{

			echo "<script> alert('error '); window.location='profile.php';</script>";

		}

		}
		?>


				<?php
		include('footer.php');?>


		
