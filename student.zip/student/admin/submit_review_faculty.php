<?php
include('header.php');
?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Faculty  Review</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						 	<thead>
							<tr>
								<th>Review Id</th>
								<th>faculty name</th>
								<th> status</th>
								<th>Type_of_review</th>
								<th>Principal investigator</th>
								<th>view more</th>
								<th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
									$sql="SELECT * FROM `apply_for_standard_review_faculty`";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
								<td><?php echo $result[0];?></td>
								<td><?php  $ros= $result['userid'];
										$ras=mysql_query("select * from faculty where fid='$ros'");
										$res=mysql_fetch_array($ras);
										echo $res[1];


								?>
									

								</td>
								<td><?php echo $result['status'];?></td>
								<td><?php echo $result['Principalinvestigator'];?></td>
								<td><?php echo $result['typeofreview'];?></td>
								<td><a href="view_submit_review_faculty.php?id=<?php echo $result[0];?>">view more </a></td>
								<td><a href="delete_review_faculty.php?id=<?php echo $result[0];?>">Delete </a></td>		
							</tr>	
							<?php		
								}
								?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			 </div>			   
<?php
include('footer.php');
?>