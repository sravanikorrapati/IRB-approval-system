<?php
include('header.php');

?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">all irb memeber</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						  <thead>
							<tr>
								  <th> Id</th>
								  <th>username</th>
								  <th>password </th>
								  <th>first_name</th>
								  <th> 	last_name</th>
								  
							</tr>
						  </thead>
						  <tbody>
								<?php
								$sql="SELECT * FROM `irb`";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
							  <td><?php echo $result[0];?></td>
							  <td><?php echo $result[1];?></td>
							  <td><?php echo $result[2];?></td>
							  <td><?php echo $result[3];?></td> 
							  <td><?php echo $result[4];?></td>
							
							
							<?php		
								}
								?>

						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>		


   
<?php
include('footer.php');
?>
