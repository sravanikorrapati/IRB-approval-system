<?php
include('../connection.php');


$rid=$_REQUEST['reviewid'];

$userid=$_REQUEST['userid'];

$error=$_REQUEST['error'];



$sql=mysql_query("INSERT INTO `review_error` (
`error_id` ,
`review_id` ,
`user_id` ,
`error` ,
`status`
)
VALUES (
NULL , '$rid', '$userid', '$error', '0'
)");

if($sql)
{

	echo "<script>alert('submit data'); window.location='profile.php';</script>";
}
else
{
	echo "<script>alert('submit error'); window.location='profile.php';</script>";
}


?>