<?php
include('header.php');

?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Faculty submit application</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						  <thead>
							<tr>
								  <th> Id</th>
								  <th> name</th>
								  <th>email</th>
								  <th>contact</th>
								  <th>question</th>
								  <th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
								$sql="SELECT * FROM `feedback`";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
							  <td><?php echo $result[0];?></td>
							  <td><?php echo $result[1];?></td>
							  <td><?php echo $result[2];?></td>
							  <td><?php echo $result[3];?></td> 
							  <td><?php echo $result['question'];?></td>
							
							   <td><a href="feedback_delete.php?id=<?php echo $result[0];?>">Delete </a></td>		
							</tr>	

							<?php		
								}
								?>

						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>		


   
<?php
include('footer.php');
?>
