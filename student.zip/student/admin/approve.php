<?php


include('../connection.php');


$appid=$_REQUEST['id'];

$sql="update application set status=1 where  appid='$appid'";
$res=mysql_query($sql);

if($res)
{


	echo "<script>alert('approve appliction'); window.location='faculty_submit_app.php'</script>";
}
else
{

	echo "<script>alert('approve error appliction'); window.location='faculty_submit_app.php'</script>";
}





?>