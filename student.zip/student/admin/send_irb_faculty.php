<?php

include('header.php');
include('../connection.php');
?>
<div id="page-wrapper">
	<div class="container">    
		<div class="row">
			<div class="col-sm-2">
			

			</div>
    <div class="col-sm-8"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Send irb member Request </div>
       	 <div class="panel-body">
			<form action="" method="post">
			 <div class="form-group">
				<label for="sel1">irb member:</label>
				<select class="form-control" id="sel1" required="" name="facultyname">
						<?php
						$sql=mysql_query("SELECT * FROM `irb`");
						while($result=mysql_fetch_array($sql))
						{
						?>
							<option value="<?php echo $result[0];?>"><?php echo $result[1];?></option>
						<?php
						}
						?>
					</select>
			</div>
				<div class="form-group">
					<label for="comment">Description:</label>
					<textarea class="form-control" rows="5" id="comment" name="description"></textarea>
				</div>
             <div class="form-group">
           		 <button type="submit" class="btn btn-primary btn-lg" name="q1">Submit</button>
          </div>
</form>
           
        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
    <div class="col-sm-2"> 
     
    </div>
			</div>
			<?php
		if(isset($_REQUEST['q1']))
		{
			
			

         $uid=$_REQUEST['id'];
         $review_id=$_REQUEST['review_id'];
         $irbmember=$_REQUEST['facultyname'];
         $description=$_REQUEST['description'];
		 $status=0;

	$res=mysql_query("INSERT INTO `student`.`admin_send_irb_faculty` (
`faculty_id` ,`id` ,`review_id` ,`description` ,`status` ,`irbmember`)VALUES ('$uid', NULL , '$review_id', ' $description', '$status', '$irbmember')");

		//print_r($result);
		if($res)
		{

			echo "<script> alert('submit  irb request'); window.location='profile.php';</script>";

		}
		else
		{
			echo "<script> alert('error  irb request'); window.location='profile.php';</script>";
		}

		}
		?>


				<?php
		include('footer.php');?>


		
