<?php
include('header.php');
?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Student Review</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						 	<thead>
							<tr>
								<th>Review Id</th>
								<th>student name</th>
								<th>student status</th>
								<th>Type_of_review</th>
								<th>Principal investigator</th>
								<th>view more</th>
								<th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
									$sql="SELECT * FROM apply_for_standard_review";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
								<td><?php echo $result[0];?></td>
								<td><?php  $user=$result['userid'];
									$sql3=mysql_query("select * from user where id ='$user'");
									$ros=mysql_fetch_array($sql3);

									echo $ros[1];




								?></td>
								<td><?php echo $result['status'];?></td>
								<td><?php echo $result['Principalinvestigator'];?></td>
								<td><?php echo $result['typeofreview'];?></td>
								<td><a href="view_submit_review.php?id=<?php echo $result[0];?>">view more </a></td>
								<td><a href="delete_review_student.php?id=<?php echo $result[0];?>">Delete </a></td>		
							</tr>	
							<?php		
								}
								?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			 </div>			   
<?php
include('footer.php');
?>