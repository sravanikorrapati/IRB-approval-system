<?php

include('../connection.php');

$fid=$_REQUEST['id'];

$sql=mysql_query("delete from user where id='$fid'");

if($sql)
{
	echo "<script>alert('Delete student'); window.location='student_view.php';</script>";	
}
else
{
	
echo "<script>alert('Delete error'); window.location='student_view.php';</script>";		
}








?>