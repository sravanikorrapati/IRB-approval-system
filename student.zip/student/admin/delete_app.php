<?php
include('../connection.php');

$id=$_REQUEST['id'];

$sql=mysql_query("delete from application where appid='$id'");

if($sql)
{

	echo "<script>alert('delete application'); window.location='faculty_submit_app.php';</script>";

}
else
{
	echo "<script>alert('delete application error'); window.location='faculty_submit_app.php';</script>";
}


