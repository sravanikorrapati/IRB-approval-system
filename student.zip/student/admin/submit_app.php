<?php
include('header.php');
?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Student submit application</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						 	<thead>
							<tr>
								<th>Review Id</th>
								<th>student name</th>
								<th>student status</th>
								<th>Type_of_review</th>
								<th>Principal investigator</th>
								<th>view more</th>
								<th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
									$sql="SELECT * FROM `review`";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
								<td><?php echo $result[0];?></td>
								<td><?php echo $result['userid'];?></td>
								<td><?php echo $result['Status'];?></td>
								<td><?php echo $result['Principal_investigator'];?></td>
								<td><?php echo $result['Type_of_review'];?></td>
								<td><a href="view_submit_app.php?id=<?php echo $result[0];?>">view more </a></td>
								<td><a href="delete_app.php?id=<?php echo $result[0];?>">Delete </a></td>		
							</tr>	
							<?php		
								}
								?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			 </div>			   
<?php
include('footer.php');
?>