<?php
include('../connection.php');


 $rid=$_REQUEST['reviewid'];

 $faculty_id=$_REQUEST['userid'];

 $error=$_REQUEST['error'];


$sql=mysql_query("INSERT INTO `review_error_faculty` (`f_id` ,`faculty_id` ,`review_id` ,`status` ,`error`)VALUES (NULL , '$faculty_id', '$rid', '0', '$error')");

print_r($sql);
if($sql)
{
	echo "<script>alert('submit data'); window.location='profile.php';</script>";
}
else
{
	echo "<script>alert('submit error'); window.location='profile.php';</script>";
}


?>
