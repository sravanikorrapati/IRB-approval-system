<?php

include('../connection.php');

 $id=$_REQUEST['id'];

$sql=mysql_query("delete from feedback where id='$id'");


if($sql)
{

	echo "<script>alert('delete data'); window.location='contact.php';</script>";

}
else
{
	echo "<script>alert('delete error');window.location='contact.php';</script>";

}



?>