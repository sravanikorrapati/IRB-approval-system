<?php
include('../connection.php');

$id=$_REQUEST['id'];

$sql=mysql_query("delete from apply_for_standard_review_faculty where id='$id'");

if($sql)
{

	echo "<script>alert('delete application'); window.location='profile.php';</script>";

}
else
{
	echo "<script>alert('delete application error'); window.location='profile.php';</script>";
}


