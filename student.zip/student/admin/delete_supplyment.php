<?php

include('../connection.php');
$id=$_REQUEST['id'];

$sql=mysql_query("delete from materials where id='$id'");

if($sql)
{


echo "<script>alert('delete successfully '); window.location='supplementry_material.php';</script>";

}





?>