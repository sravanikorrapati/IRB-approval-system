<?php

include('../connection.php');

$fid=$_REQUEST['id'];

$sql=mysql_query("delete from faculty where fid='$fid'");

if($sql)
{
	echo "<script>alert('Delete faculty'); window.location='faculty_view.php';</script>";	
}
else
{
	
echo "<script>alert('Delete error'); window.location='faculty_view.php';</script>";		
}








?>