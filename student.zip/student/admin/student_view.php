<?php
include('header.php');
?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Student information</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
				<table class="table">
						  <thead>
							<tr>
							  <th>id</th>
							  <th>name</th>
							  <th>type</th>
							  <th>description</th>
							  <th>status</th>
							  <th>edit</th>
							  <th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
								$sql="SELECT * FROM `user`";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{
									//print_r($result);
								?>
							<tr class="active">
							  <th scope="row"><?php echo $result[0];?></th>
							  <td><?php echo $result[1];?></td>
							  <td><?php echo $result[2];?></td>
							  <td><?php echo $result[3];?></td>
							  <td><?php echo $result[4];?></td>
							  <td><a href="student_edit.php?id=<?php echo $result[0];?>">edit</a></td>
							  <td><a href="student_delete.php?id=<?php echo $result[0];?>">Delete</a></td>
							  
							</tr>																						<?php		
								}
								?>
						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>
					   












<?php

include('footer.php');
?>