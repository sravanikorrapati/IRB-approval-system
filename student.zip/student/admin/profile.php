<?php

include('header.php');
?>
			<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Hi <?php echo $result['username'];?> welcome to IRB Home page admin panel</h3>
					<!-- <div class="graph_box">
						<div class="col-md-4 grid_2">
							<div class="grid_1">
								<h4>Apply for standard review</h4>
								
							
							</div>
						</div>
						<div class="col-md-4 grid_2">
							<div class="grid_1">
								<h4>Submit application</h4>
								
								
								</div>
						</div>
						<div class="col-md-4 grid_2">
							<div class="grid_1">
								<h4>Upload supplementry materials</h4>
								
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="graph_box1">
						<div class="col-md-6 grid_2 grid_2_bot">
							<div class="grid_1">
								<h4>Sponsorship Request</h4>
							

							
							</div>
						</div>
						<div class="col-md-6 grid_2 grid_2_bot">
							<div class="grid_1">
								<h4>View submitted Application</h4>
								
							</div>
							<div class="line-bottom-grid">
								<div class="grid_1">
									<h4>sponsoring candidates</h4>
									
								</div>
							</div>
						</div> -->
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
		</div>
		<?php
		include('footer.php');?>
		