<?php

include('../connection.php');
include('header.php');
error_reporting(0);
$id=$_REQUEST['id'];
$result=mysql_query("select * from apply_for_standard_review_faculty where id='$id'");
$res=mysql_fetch_array($result);
//rint_r($res);
?>
<div id="page-wrapper">
  <div class="container">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../user/style.css"/>
<script src="../user/multi_step_form.js"></script>
<div class="content">
<!-- multistep form -->
<div  class="main">
<form class="regform" action="Apply_for_standard_review_insert.php" method ="get">
<h1>check faculty review </h1>
  <!-- progressbar -->
  <ul id="progressbar">
    <li class="active">step 1</li>
    <li>step 2</li>
    <li>step 3</li>
  </ul>
  
  <!-- fieldsets -->
                    <fieldset id="first">
                    <h2 class="title">Step 1</h2>
                    <div class="form-group">
                    <label for="inputEmail">Type of review*</label>
                     <input type="text" class="form-control" id="usr" name="email_invester" value="<?php echo $res['typeofreview'];?> ">
                    </div>
                    <div class="form-group">
                    <label>Principal investigator *</label>
                    <input type="text" class="form-control" id="usr" name="Principal_ans" value="<?php echo $res['Principalinvestigator'];?>">
                    </div>
                    <div class="form-group">
                    <label>Title of Research Study Proposal: *</label>
                    <input type="text" class="form-control" id="usr" name="study_propos" value="<?php echo  $res['study_propos'];?>"/>
                    </div>
                    <div class="form-group">
                    <label>Investigator mailing address: *</label>
                    <input type="text" class="form-control" id="usr" name="inves_mail"value="<?php echo  $res['inves_mail'];?>"">
                    </div>
                    <div class="form-group">
                    <label>Investigator telephone *</label>
                    <input type="text" class="form-control" id="usr" name="inves_tele" value="<?php echo  $res['inves_tele'];?>">
                    </div>
                    <div class="form-group">
                    <label>Email*</label>
                    <br/>
                  
                    <input type="text" class="form-control" id="usr" name="email_invester" value="<?php echo  $res['email_invester'];?>">
                    </div>
                    <div class="form-group">
                      <label for="sel1">Status*</label>
                        <input type="text" class="form-control" id="usr" name="email_invester" value="<?php echo  $res['status'];?>">
                    </div>
                    <div class="form-group">
                    <label>Sponsor name and degree*</label>
                    <input type="text" class="form-control" id="usr" name="Sponsor_name" value="<?php echo  $res['Sponsor_name'];?>">
                    </div>
                    <div class="form-group">
                    <label>Faculty sponsor’s signature</label>
                    <label>Faculty sponsor’s office*</label>
                    <input type="text" class="form-control" id="usr" name="fac_office" value="<?php echo  $res['fac_office'];?>">
                    </div>
                    <div class="form-group">
                    <label>Mailing address*</label>
                    <input type="text" class="form-control" id="usr" name="address" value="<?php echo  $res['address'];?>">
                    </div>
                    <div class="form-group">
                    <label>Telephone</label>
                    <input type="text" class="form-control" id="usr" name="telephone" value="<?php echo  $res['telephone'];?>">
                    </div>
                    <div class="form-group">
                    <label>E-mail</label>
                    <input type="text" class="form-control" id="usr" name="email" value="<?php echo  $res['inves_email'];?>">
                    </div>
                    <div class="form-group">
                    <label for="sel1">Are there co-investigators? </label>
                    <input type="text" class="form-control" id="usr" name="email" value="<?php echo  $res['coinvestigators'];?>">
                  
                  </div>
                    <input type="button" name="next" class="next_btn" value="Next" />
                    <!-- <input type="submit" name="s1" class="submit_btn" value="save" /> -->
                    <BR/> <BR/> <BR/>
  
  </fieldset>
  <fieldset>

    <h2 class="title">Step-2</h2>
                  <div class="form-group">
                  Co-Investigator (typed):<BR/>
                  <label>CO INVESTIGATORS names</label>
                  <input type="text" class="form-control" id="usr" name="co_invet" value="<?php echo $res['co_invetname'];?>">
                  </div>
                  <div class="form-group">
                  <label>Co investigator mailing address</label>
                  <input type="text" class="form-control" id="usr" name="co_invet_mail" value="<?php echo $res['co_invet_mail'];?>">
                  </div>
                  <div class="form-group">
                  <label>Co investigator email address</label>
                  <input type="text" class="form-control" id="usr" name="co_invet_email" value="<?php echo $res['co_invet_mail'];?>"/>
                  </div>

             <!--      <div class="form-group">
                  <label>co investigator telephone number</label>
                  <input type="text" class="form-control" id="usr" name="co_invet_tele" value="<?php //echo $res[];?>"/>
                  </div> -->
                  <div class="form-group">
                  <label>. Please check applicable categories.  This research study proposal is:  </label>
                   <input type="text" class="form-control" id="usr" name="co_invet_email" value="<?php echo $res['applicable_categories'];?>"/>
               
                  </div>
                  <div class="form-group">
                  <label>If the proposal is a grant application, indicate the funding agency</label>
                  <input type="text" class="form-control" id="usr" name="grnt_app" value="<?php echo $res['grnt_app'];?>">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail">Is notification of IRB approval required by the granting agency</label><BR/>
                     <input type="text" class="form-control" id="usr" name="IRB_approval" value="<?php echo $res['IRB_approval'];?>">
                  </div>
                  <div class="form-group">
                  <label>If the proposal is a grant application, indicate the funding agency</label>
                  <input type="text" class="form-control" id="usr" name="funding_agency" value="<?php echo $res['funding_agency'];?>">
                  </div>
                  <div class="form-group">
                  <label>Data gathering start date:</label>
                  <input type="text" class="form-control" id="usr" name="start_date"  value="<?php echo $res['start_data'];?>" />
                  </div>
                  <div class="form-group">
                    <label>Data gathering end date:</label>
                    <input type="text" class="form-control" id="usr" name="end_date" value="<?php echo $res['end_data'];?>">
                  </div>
                  <div class="form-group">
                  <input type="text" class="form-control" id="usr" name="end_date" value="<?php echo $res['projected_study'];?>">
                  </div>
    <input type="button" name="previous" class="pre_btn" value="Previous" />
    <input type="button" name="next" class="next_btn" value="Next" />
    <BR/><BR/><BR/>
  </fieldset>
  <fieldset>
      <h2 class="title">Step 3</h2>
      <div class="form-group">
        <label for="inputEmail">Purpose: What is the purpose of the research? State the hypothesis or research question</label>
        <input type="text" class="form-control" id="usr" name="purpose" value="<?php echo $res['purpose'];?>">
      </div>
      <div class="form-group">
      <label for="inputEmail">Methodology: How will the research be conducted?</label>
        <input type="text" class="form-control" id="usr" name="methodology" value="<?php echo $res['methodology'];?>">
      </div>
      <div class="form-group">
        <label for="inputEmail">SUBJECTS: Who will be the research subjects? Please select one.</label>
         <input type="text" class="form-control" id="usr" name="methodology" value="<?php echo $res['subject'];?>">
     

    </div>

    <div class="form-group">
      <label>If research subjects will be selected from a vulnerable population, please select all that apply:</label>
      <textarea id="comment" class="form-control" rows="5" name="error">value="<?php echo $res['vulnerable'];?>"</textarea>
    <div class="form-group">
    <label>State the rationale for using vulnerable populations. What safeguards will be used to protect members of a vulnerable population?</label>
    <input type="text" class="form-control" id="usr" name="population" value="<?php echo $res['population'];?>">
    </div>
    <div class="form-group">
      <label>What is the approximate total number of subjects to be recruited?</label>
      <input type="text" class="form-control" id="usr" name="recruited" value="<?php echo $res['recruited'];?>">
    </div>
    <div class="form-group">
      <label>How will the subjects be recruited/solicited? Please check all that apply.</label>
      <input type="text" class="form-control" id="usr" name="recruited" value="<?php echo $res['solicited'];?>">
    </div>
      <div class="form-group">
      <table border="1">
      <tr>
        <th>Risk Criteria assessment</th>
        <th>choose one</th>
    </tr>
    
    <tr>
    <td>
     With respect to any of the above criteria, subjects are at risk.></td>
     <td><?php echo $res['subjects_are_at_risk'];?></td>
     </tr>
     <tr>
     <td>Experimental drugs will be used.</td>
      <td><?php echo $res['drugs'];?></td>
     </tr>
     <tr>
       <td>
         Potential for a medical problem exists.</td>
         <td><?php echo $res['medical'];?></td>
         
     </tr>
      <tr>
       <td>
       Subjects may experience physical discomfort greater than in everyday life.</td>
        <td><?php echo $res['physical_discomfort'];?></td>
        
     </tr>
     <tr>
       <td>
       Subjects may experience mental discomfort greater than in everyday life.</td>
       <td><?php echo $res['mental_discomfort'];?></td>
     </tr>
     <tr>
       <td>
       Electrical equipment will be used..</td>
       <td><?php echo $res['Electrical_equipment'];?></td>
     </tr>
     <tr>
     
       <td>Subjects will be tape recorded, photographed, or videotaped.</td>
       <td><?php echo $res['videotaped'];?></td>
     </tr>
     </table>
      <div class="form-group">
      <label for="inputEmail">Does any part of this activity have the potential for coercion of the subject?</label>
        <input type="text" class="form-control" id="usr" name="recruited" value="<?php echo $res['coercion'];?>">
    
      </div>

      <div class="form-group">
        <label for="inputEmail">Are the subjects exposed to deception?</label>
         <input type="text" class="form-control" id="usr" name="recruited" value="<?php echo $res['exposed'];?>">
      </div>
      <div class="form-group">
        <label for="inputEmail">What possible benefits could the subject derive from participation in the proposed research study?</label>
        <input type="text" class="form-control" id="usr" name="benefits"  value="<?php echo $res['benefits'];?>">
      </div>
      <div class="form-group">
        <label for="inputEmail">What contributions to general knowledge in the field of inquiry or possible benefits could be derived from the research?</label>
        <input type="text" class="form-control" id="usr" name="eresarch"  value="<?php echo $res['research'];?>">
      </div>
      <div class="form-group">
        <label for="inputEmail">If subjects will be rewarded or compensated, state the amount, types, and timetable for compensation. If subjects are recruited from Gannon University classes, state whether students are receiving course credit (regular or extra credit) and state alternatives offered to students who do not wish to participate.</label>
         <input type="text" class="form-control" id="usr" name="eresarch"  value="<?php echo $res['rewarded'];?>">
      </div>
      <div class="form-group">
        <label for="inputEmail">Choose one</label>
        <input type="text" class="form-control" id="usr" name="eresarch"  value="<?php echo $res['choose_one'];?>">
      </div>
      <div class="form-group">
          <label>What type of consent will be used?  Check all that apply.</label>
          <input type="text" value="<?php echo $res['check_all_that_apply'];?>">          
      </div>
      <div class="form-group">
        <label>Describe how and by whom the consent forms and other material will be distributed and collected to protect confidentiality and subject anonymity.</label>
        <input type="text" class="form-control" id="usr" name="subject_anonymity" value="<?php echo $res['informed'];?>">
      </div>
        <div class="form-group">
        <label for="inputEmail">Are subjects informed that they may withdraw at any time without penalty</label>
         <input type="text" class="form-control" id="usr" name="subject_anonymity" value="<?php echo $res['rationale_decision'];?>">
      </div>
    <div class="form-group">
    <label>If not, describe the rationale for this decision.</label>
      <input type="text" class="form-control" id="usr" name="rationale_decision" value="<?php echo $res['describe_the_rationale'];?>">
    </div>  
    <div class="form-group">
    <label>If a written consent will not be used, describe the rationale for this decision.</label>
      <input type="text" class="form-control" id="usr" name="describe_the_rationale " placeholder="Enter Answer">
    </div>

    <div class="form-group">
      <label>If oral consent will be used, describe how consent will be documented.  Provide script for oral consent.</label>
      <input type="text" class="form-control" id="usr" name="oral_consent" value="<?php echo $res['be_documented'];?>">
    </div>

    <div class="form-group">
      <label>If minors will be participating and a parental consent form will not be used, describe the rationale</label>
      <input type="text" class="form-control" id="usr" name="describe_the_rationale" value="<?php echo $res['minors'];?>">
    </div>
   
    <div class="form-group">
      <label>If minors aged 7 to 17 will be participating and an assent form for minors will not be used, describe the rationale.</label>
      <input type="text" class="form-control" id="usr" name="minors_aged" value="<?php echo $res['minors_aged'];?>">
    </div>
    <div class="form-group">
      <label>If the primary investigator is requesting that consent be waived, describe the rationale.</label>
      <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['primary_investigator'];?>">
    </div>
    <div class="form-group">
    <table border="1">
    <tr>
      <td colspan="3">checklist of required elements contained in an informed consent document or script for a study that involves no more than minimal risk</td>
    </tr>
    <tr>
      <td>R01. Statement that the study involves research.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['R01'];?>"></td>
    </tr>
    <tr>
      <td> R02. Title of the study</td>
       <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['title_of_the_study'];?>"></td>
    </tr>
    <tr>
      <td>R03. Name of principal investigator/primary researcher.</td>
       <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['investigator'];?>"></td>
    </tr>
    <tr>
      <td>R04. Statement that participation is voluntary.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['prticipation_is_voluntary'];?>"></td>
    </tr>
      <tr>
      <td>R05. Explanation of purposes of study.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['purposes_of_study'];?>"></td>
    </tr>

    <tr>
      <td>R06. Accounting of the expected duration of subject’s participation</td>
      td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['duration_of_subject'];?>"></td>
    </tr>
    
    <tr>
      <td>R07. Description of procedures to be followed.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['procedures_to_be_followed'];?>"></td>
    </tr>
    <tr>
      <td>R08. Explanation of extent to which confidentiality will be maintained.</td>
   td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['confidentiality'];?>"></td>
    </tr>
    <tr>
      <td>R09.Identification of benefits to subject or to others from the research.</td>
      td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['benefits_to_subject'];?>"></td>
    </tr>
    <tr>
      <td> R10. Identification of any procedures which are experimental.</td>
      td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['subject_anonymity'];?>"></td>
    </tr>
      <tr>
      <td>R11. Description of possible physical omentar l risk or discomfort.</td>
      td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['oral_consent'];?>"></td>
    </tr>
    <tr>
      <td>R12. Statement that refusal to participate will involve no penalty.</td>
      td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['involves_research'];?>"></td>
    </tr>
    <tr>
      <td>R13. Name contact person for questions about the study.</td>
      td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['experimental'];?>"></td>
    </tr>
    <tr>
      <td>R14. Name contact person for questions about the subjects’ rights.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['physical_omentar'];?>"></td>
    </tr>
    <tr>
      <td>R15. Notification if subjects will be recorded or photographed.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['refusal_to_participate'];?>"></td>
    </tr>
    <tr>
      <td>R16. Description of procedures by which subjects may discontinue participation.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['questions_about_the_study'];?>"></td>
    </tr>
    
    <tr>
      <td>R17. Informed consent documents have a Reading Level of ≤8.0 by Microsoft Word calculation.</td>
      <td> <input type="text" class="form-control" id="usr" name="primary_investigator" value="<?php echo $res['duration_of_subject'];?>"></td>
    </tr>

    </table>
  </div>
    <div class="form-group">
      <label>Explain any “No” answers checked for R01-R17 in this space:</label>
      <input type="text" class="form-control" id="usr" name="checked"  value="<?php echo $res['Explain_any'];?>">
  </div>
  <div class="form-group">
          <label>Data collection methods.  Please check all that apply.  Attach copies of tools and study instruments, including interview script, if used.</label>
      <textarea class="form-control"><?php    echo $res['Data_collection_methods'];?></textarea>
  </div>
  <div class="form-group">

    <label>(All options here are check boxes and upload is for attaching the docs related to any of the above options which ever checked in while filling the form)</label>
    <table>
      <tr>
        <td>Will the data be collected with identifiers?</td>
      <td><input type="text" class="form-control" id="usr" name="identifiers_for_analysis" placeholder="Here"  value="<?php echo $res['collected_with_identifiers'];?>"></td>
      </tr>
      <tr>
        <td>Will the data retain identifiers for analysis? </td>
        <td><input type="text" class="form-control" id="usr" name="identifiers_for_analysis" placeholder="Here"  value="<?php echo $res['identifiers_for_analysis'];?>"></td>
        <td></td>
      </tr>
      <tr>
        <td> Will the data retain identifiers for reporting? </td>
        <td></td>
        <td><input type="text" class="form-control" id="usr" name="identifiers_for_reporting" placeholder="Here"  value="<?php echo $res['identifiers_for_reporting'];?>"></td>
      </tr>
    </table>
  </div>
  <div class="form-group">
    <label>Describe if or how research findings will be disseminated to subjects.  </label>
      <input type="text" class="form-control" id="usr" name="disseminated"  value="<?php echo $res['disseminated'];?>">
  </div>
  <div class="form-group">
      Describe provisions of maintaining security of the data.  
      Note: Data should be secured while collection is in progress and when stored.  Provide a plan for data storage for at least 3 years.
      <label>(a) storage arrangements for the consent forms and other material</label>
      <input type="text" class="form-control" id="usr" name="arrangements" value="<?php echo $res['arrangements'];?>"> 
  </div>
  <div class="form-group">
      <label>(b) an accounting of the persons who will have access to identified data </label>
      <input type="text" class="form-control" id="usr" name="accounting" placeholder="Here"  value="<?php echo $res['accounting'];?>">
  </div>
  <div class="form-group">
      <label>(c) schedule and methods for de-identification of data, if appropriate</label>
      <input type="text" class="form-control" id="usr" name="de-identification"  value="<?php echo $res['de_identification'];?>">
  </div>
    <div class="form-group">
      <label>(d) schedule and methods for long-term storage of raw data </label>
      <input type="text" class="form-control" id="usr" name="long-term-storage" value="<?php echo $res['long_term_storage'];?>">
    </div>
    <div class="form-group">
      <label>(e) schedule and methods for eventual destruction of data.</label>
      <input type="text" class="form-control" id="usr" name="eventual" value="<?php echo $res['eventual'];?>">
    </div>
    <input type="hidden" name="userid" value="<?php echo $result[0];?>"/>
        <input type="button" class="pre_btn" value="Previous" />
         <a href="send_error_report_faculty.php?id=<?php echo $res['userid'];?>&review_id=<?php echo $res[0];?>"><input type="button" class="pre_btn" value="send student"/></a>
        <a href="send_irb_faculty.php?id=<?php echo $res['userid'];?>&review_id=<?php echo $res[0];?>"><input type="button" name="s1" class="submit_btn" value="send irb" /></a><BR/><BR/><BR/>
      </fieldset>
</form>
</div>
</div>
</div>  
  </div>
</div>

         <?php

include('footer.php');
         ?>
