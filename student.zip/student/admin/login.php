<?php
include('../connection.php');
session_start();

$username=$_REQUEST['username'];
$password=$_REQUEST['password'];

$sql=mysql_query("SELECT * FROM `admin` WHERE  username='$username' AND password='$password'");


if(mysql_affected_rows()>0)
{
	
	$_SESSION['username']=$username;
	
	echo "<script>alert('login suessfully'); window.location='profile.php';</script>";
	
}
else
{
	
	echo "<script>alert('login error'); 
	
				window.location='index.php'</script>";
	
	
}
	



?>