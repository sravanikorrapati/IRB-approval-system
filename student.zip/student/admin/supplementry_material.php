<?php
include('header.php');
?>


<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">supplyments information</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
				<table class="table">
						  <thead>
							<tr>
							  <th>App id</th>
							  <th>Faculty Name</th>
							  <th>Name</th>
							  <th>Type</th>
							  <th>Description</th>
							  <th>Document</th>
							  <th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
								$sql="SELECT * FROM `materials`";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{

								?>
							<tr class="active">
							  <th scope="row"><?php echo $result[0];?></th>
							  <td><?php echo $result['fid'];

							 	/*$uid=$result[5];

							 	$query=mysql_query("select * from faculty  where fid='$uid'");
							 	$result1=mysql_fetch_array($query);
							 	echo $result1['firstname'];*/	?>
							  </td>
							  <td><?php echo $result[1];?></td>
							  <td><?php echo $result[2];?></td>
							  <td><?php echo $result[3];?></td>
							  <td><a href="../faculty/file/<?php echo $result['file'];?>"><img src="../faculty/file/<?php echo $result['file'];?>" height="60px" width="60px"></a></td> 
							  <td><a href="delete_supplyment.php?id=<?php echo $result[0];?>">delete</a></td>	
							</tr>	
																											
							<?php		
								}
								?>
						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>
					   












<?php

include('footer.php');
?>