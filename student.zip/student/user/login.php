<?php
include('../connection.php');
session_start();

$email=$_REQUEST['email'];
$password=$_REQUEST['password'];

$sql=mysql_query("SELECT * FROM `user` WHERE  email='$email' AND password='$password'");


if(mysql_affected_rows()>0)
{
	
	$_SESSION['email']=$email;
	
	echo "<script>alert('login successfully'); window.location='profile.php';</script>";
	
}
else
{
	
	echo "<script>alert('login error'); 
	
				window.location='user_login.php';</script>";
	
	
}
	



?>