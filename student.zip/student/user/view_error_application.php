<?php
include('header.php');
?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">view  error application</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						 	<thead>
							<tr>
								<th>error_id</th>
								<th>review_id</th>
								<th>error</th>
								<th>status</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
								$userid=$result[0];

									$sql="SELECT * FROM `review_error` where user_id='$userid' ";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
								<td><?php echo $result['error_id'];?></td>
								<td><?php echo $result['review_id'];?></td>
								<td><?php echo $result['error'];?></td>
								<td><?php 
								if($result['status']==0)
								{

									echo "pandding";

								}
								else
								{
									echo "approve";


								}
							

?></td>
								
									
							</tr>	
							<?php		
								}
								?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			 </div>			   
<?php
include('footer.php');
?>