<?php
error_reporting(0);
include('../connection.php');
			$userid=$_REQUEST['userid'];
			$typeofreview=$_REQUEST['r1'];
			$Principalinvestigator=$_REQUEST['Principal_ans'];
			$study_propos=$_REQUEST['study_propos'];
			$inves_mail=$_REQUEST['inves_mail'];
			$inves_tele=$_REQUEST['inves_tele'];
			$email_invester=$_REQUEST['email_invester'];
			$status=$_REQUEST['student'];
			$Sponsor_name=$_REQUEST['Sponsor_name'];
			$fac_office=$_REQUEST['fac_office'];
			$address=$_REQUEST['address'];
			$telephone=$_REQUEST['telephone'];
			$inves_email=$_REQUEST['email'];
			$coinvestigators=$_REQUEST['co-investigators'];
			$co_invetname=$_REQUEST['co_invet'];
			$co_invet_mail=$_REQUEST['co_invet_mail'];
			$co_invet_email=$_REQUEST['co_invet_email'];
			$co_invet_tele=$_REQUEST['co_invet_tele'];
			$check=$_REQUEST['chk1'];
			$applicable_categories=implode(',', $check);
			$grnt_app=$_REQUEST['grnt_app'];
			$start_data=$_REQUEST['start_date'];
			$end_data=$_REQUEST['end_date'];
			$projected_study=$_REQUEST['r3']; 
			//not error
			$purpose=$_REQUEST['purpose'];
			$methodology=$_REQUEST['methodology'];
			$subject=$_REQUEST['r4'];
			$vulnerable=implode(',', $_REQUEST['chk9']);
			$population=$_REQUEST['population'];
			$recruited=$_REQUEST['recruited'];
			$solicited=implode(',', $_REQUEST['chk5']);
			$chk91=$_REQUEST['chk91'];
			$research_subjects=implode(',', $chk91);
			$chk92=$_REQUEST['yes'];
			$subjects_are_at_risk=implode(',', $chk92);
			$drugs=implode(',', $_REQUEST['yes1']);
			$medical=implode(',', $_REQUEST['yes2']);
			$physical_discomfort=implode(',', $_REQUEST['yes3']);
			$mental_discomfort =implode(',', $_REQUEST['yes5']);
			$Electrical_equipment=implode(',', $_REQUEST['yes6']);
			$videotaped=implode(',', $_REQUEST['yes7']);
			$coercion=$_REQUEST['r13'];
			$exposed=$_REQUEST['r14'];
			$benefits=$_REQUEST['benefits'];
			$research=$_REQUEST['eresarch'];
			$irb=$_REQUEST['r2'];
			$funding_agency=$_REQUEST['funding_agency'];

			/*===========*/
			$rewarded=$_REQUEST['r15'];
			$choose_one=$_REQUEST['r18'];
			$check_all_that_apply=implode(',', $_REQUEST['chk12']);
			//$eresarch=$_REQUEST['eresarch'];
			$informed=$_REQUEST['informed'];
			$rationale_decision=$_REQUEST['rationale_decision'];
			$describe_the_rationale=$_REQUEST['describe_the_rationale'];
			$be_documented=$_REQUEST['be_documented'];
			$minors=$_REQUEST['minors'];
			$minors_aged=$_REQUEST['minors_aged'];
			$primary_investigator=$_REQUEST['primary_investigator'];
			$R01=$_REQUEST['sa'];
			$title_of_the_study=$_REQUEST['ch'];
			$investigator=$_REQUEST['in'];
			$prticipation_is_voluntary=$_REQUEST['sh'];
			$purposes_of_study=$_REQUEST['ra'];
			$duration_of_subject=$_REQUEST['ha'];
			$procedures_to_be_followed=$_REQUEST['ga'];
			$confidentiality=$_REQUEST['rh'];

		

			$benefits_to_subject =$_REQUEST['r15'];
			$subject_anonymity=$_REQUEST['subject_anonymity'];
			$oral_consent=$_REQUEST['oral_consent'];
			$involves_research=$_REQUEST['sa'];
			$experimental=$_REQUEST['r16'];
			$physical_omentar=$_REQUEST['r17'];
			$refusal_to_participate=$_REQUEST['r18'];
			$questions_about_the_study=$_REQUEST['r19'];
			$person_for_questions =$_REQUEST['r20'];
			$photographed=$_REQUEST['r21'];
			$discontinue_participation=$_REQUEST['r22'];
			$consent_documents=$_REQUEST['r23'];
			$Explain_any=$_REQUEST['checked'];
			$Data_collection_methods=$_REQUEST['chk51'];
			$collected_with_identifiers=$_REQUEST['r24'];
			$identifiers_for_analysis=$_REQUEST['r25'];
			$identifiers_for_reporting=$_REQUEST['r27'];
			$disseminated=$_REQUEST['disseminated'];
			$arrangements=$_REQUEST['arrangements'];
			$accounting=$_REQUEST['accounting'];
			$de_identification=$_REQUEST['de-identification'];
			$long_term_storage=$_REQUEST['long-term-storage'];
			$eventual=$_REQUEST['eventual'];
					$sql="INSERT INTO `apply_for_standard_review`(`id`, `userid`, `typeofreview`, `Principalinvestigator`, `study_propos`, `inves_mail`, `inves_tele`, `email_invester`, `status`, `Sponsor_name`, `fac_office`, `address`, `telephone`, `inves_email`, `coinvestigators`, `co_invetname`, `co_invet_mail`, `co_invet_email`, `applicable_categories`, `grnt_app`, `funding_agency`,`IRB_approval`, `start_data`, `end_data`, `projected_study`, `purpose`, `methodology`, `subject`, `vulnerable`, `population`, `recruited`, `solicited`, `research_subjects`, `subjects_are_at_risk`, `drugs`, `medical`, `physical_discomfort`, `mental_discomfort`, `Electrical_equipment`, `videotaped`, `coercion`, `exposed`, `benefits`, `research`, `rewarded`, `choose_one`, `check_all_that_apply`, `informed`, `rationale_decision`, `describe_the_rationale`, `be_documented`, `minors`, `minors_aged`, `primary_investigator`, `R01`, `title_of_the_study`, `investigator`, `prticipation_is_voluntary`, `purposes_of_study`, `duration_of_subject`, `procedures_to_be_followed`, `confidentiality`, `benefits_to_subject`, `subject_anonymity`, `oral_consent`, `involves_research`, `experimental`, `physical_omentar`, `refusal_to_participate`, `questions_about_the_study`, `person_for_questions`, `photographed`, `discontinue_participation`, `consent_documents`, `Explain_any`, `Data_collection_methods`, `collected_with_identifiers`, `identifiers_for_analysis`, `identifiers_for_reporting`, `disseminated`, `arrangements`, `accounting`, `de_identification`, `long_term_storage`, `eventual`) VALUES (NULL, '$userid', '$typeofreview', '$Principalinvestigator', '$study_propos', '$inves_mail', '$inves_tele', '$email_invester', '$status', '$Sponsor_name', '$fac_office', '$address', '$telephone', '$inves_email', '$coinvestigators', '$co_invetname', '$co_invet_mail', '$co_invet_email', '$co_invet_tele', '$check', '$applicable_categories', '$grnt_app',`$funding_agency`,'$irb',$start_data', '$end_data', '$projected_study', '$purpose', '$methodology', '$subject', '$vulnerable', '$population', '$recruited', '$solicited', '$research_subjects', '$subjects_are_at_risk', '$drugs', '$medical', '$physical_discomfort', '$mental_discomfort', '$Electrical_equipment', '$videotaped', '$coercion', '$exposed', '$benefits', '$research', '$rewarded', '$choose_one', '$check_all_that_apply', '$informed', '$rationale_decision', '$describe_the_rationale', '$be_documented', '$minors', '$minors_aged', '$primary_investigator', '$R01', '$title_of_the_study', '$investigator', '$prticipation_is_voluntary', '$purposes_of_study', '$duration_of_subject', '$procedures_to_be_followed', '$confidentiality', '$benefits_to_subject', '$involves_research', '$experimental', '$physical_omentar', '$refusal_to_participate', '$questions_about_the_study', '$person_for_questions', '$photographed', '$discontinue_participation', '$consent_documents', '$Explain_any', '$Data_collection_methods', '$collected_with_identifiers', '$identifiers_for_analysis', '$identifiers_for_reporting', '$disseminated', '$arrangements', '$accounting', '$de_identification', '$long_term_storage', '$eventual')";
					$result=mysql_query($sql);


					if($result)
					{


						echo "<script>alert('submit data'); window.location='profile.php'</script>";

					}
					else
					{
						echo "<script>alert('error');  window.location='profile.php';</script>";
					}


			?>
