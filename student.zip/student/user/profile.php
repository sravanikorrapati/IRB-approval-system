<?php
	include('header.php');
?>

			<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Hi <?php echo $result['firstname'];?> welcome to IRB Home page</h3>
					 <div class="graph_box">
						<div class="col-md-4 grid_2">
							<div class="grid_1">
								<a href="Apply_for_standard_review.php"><h4>Apply for standard review</h4></a>
							</div>
						</div>
						<div class="col-md-4 grid_2">
							<div class="grid_1">
								<h4><a href="Sponsorship.php">Sent Sponsorship Request</a></h4>
							 </div>
						</div>
						<div class="col-md-4 grid_2">
							<div class="grid_1">
								<a href="view_Sponsorship.php"><h4> View Sponsorship Request</h4></a>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="graph_box1">
						<div class="col-md-6 grid_2 grid_2_bot">
							<div class="grid_1">
								<a href="review.php"><h4> Submit Application</h4></a>
							</div>
						</div>
						<div class="col-md-6 grid_2 grid_2_bot">
							<div class="grid_1">
								<a href="supplymnet.php"><h4>Upload supplementry materials</h4></a>
								
							</div>
							<!-- <div class="line-bottom-grid">
								<div class="grid_1">
									
							</div>
						</div> -->
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
		</div>
		<?php
		include('footer.php');?>
		