<?php
include('header.php');

$fid=$_SESSION['email'];
$sql="SELECT * FROM `user` where email='$fid'";
$sql1=mysql_query($sql);
$result=mysql_fetch_array($sql1);
//print_r($result);
?>
<style>
input[type="submit"] {
    background: rgb(244, 67, 54) none repeat scroll 0 0;
    border: medium none;
    color: white;
    font-size: 1em;
    outline: medium none;
    padding: 10px 0;
    text-align: center;
    transition: all 0.5s ease 0s;
    width: 18% !important;
</style>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Edit user information</h3>
			<form  action="" method=
			"post" class="form-horizontal">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">user Id</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="focusedinput" value="<?php echo $result[0];?>" name="id"  disabled>
									</div>
									<div class="col-sm-2">
									</div>
								</div>
								<div class="form-group">
									<label  class="col-sm-2 control-label">First Name</label>
									<div class="col-sm-8">
										<input  type="text" class="form-control1" name="firstname"  value="<?php echo $result[1];?>">
									</div>
								</div>
									<div class="form-group">
									<label  class="col-sm-2 control-label">Last Name</label>
									<div class="col-sm-8">
										<input  type="text" class="form-control1" name="lastname"value="<?php echo $result[2];?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label">Email</label>
									<div class="col-sm-8">
										<input  type="text" name="email" class="form-control1" value="<?php echo $result[3];?>">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword" class="col-sm-2 control-label">Password</label>
									<div class="col-sm-8">
										<input type="text" name="password" class="form-control1" id="inputPassword"  value="<?php echo $result[4];?>">
									</div>
								</div>
								<div class="col-sm-8 col-sm-offset-2">
								<input type="submit" class="btn-success btn" value="Submit" name="s1">
								
								</div>
						
					</form>
					
					
				</div>
			</div>
					   





<?php

if(isset($_REQUEST['s1']))
{

		$fid=$_REQUEST['id'];
		$lastname=$_REQUEST['lastname'];
$firstname=$_REQUEST['firstname'];
$email=$_REQUEST['email'];
		$password=$_REQUEST['password'];
		
		$sql=mysql_query("UPDATE `user` SET `firstname` = '$firstname',
			`lastname` = '$lastname',
			`email` = '$email',
			`password` = '$password' WHERE `id` ='$fid'");
			
			if($sql)
			{
					
				echo "<script>alert('update sucessfully');window.location='profile.php';</script>";	
			}
			else
			{
			echo "<script>alert('update error'); window.location='profile.php';</script>";	
			}
	
}


?>



<?php

include('footer.php');
?>