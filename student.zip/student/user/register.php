<?php

include('../connection.php');

$firstname=$_REQUEST['firstname'];
$lastname=$_REQUEST['lastname'];
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];

$sql=mysql_query("INSERT INTO `user` (`id`, `firstname`, `lastname`, `email`, `password`) VALUES (NULL, '$firstname', '$lastname', '$email', '$password')");
 

if($sql)
{
	
	
	echo "<script> alert('you are register'); window.location='user_login.php';</script>";
	
	
	
}
else
{
	
	echo "<script> alert('you not register');  window.location='user_login.php';</script>";
	
	
}
?>


