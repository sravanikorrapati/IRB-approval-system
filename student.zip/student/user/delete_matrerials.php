<?php
include('../connection.php');
$id=$_REQUEST['id'];

$sql=mysql_query("DELETE FROM `student`.`materials_student` WHERE `id`='$id'");

if($sql)
{


echo "<script>alert('delete'); window.location='uplaod_matarials.php'</script>";

}
else
{
	echo "<script>alert('error'); window.location='uplaod_matarials.php'</script>";

}






?>