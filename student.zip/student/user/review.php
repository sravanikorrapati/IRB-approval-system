﻿<?php
include('header.php');
?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css"/>
<script src="multi_step_form.js"></script>
<div class="content">
<!-- multistep form -->
<div  class="main">
<form class="regform" action="submitreview.php" method ="get">
	<!-- progressbar -->
	<ul id="progressbar">
		<li class="active">step 1</li>
		<li>step 2</li>
		<li>step 3</li>
	</ul>
	
	<!-- fieldsets -->
	<fieldset id="first">
		<h2 class="title">Step 1</h2>
		<div class="form-group">
										<label for="inputEmail">Type of review*</label>
										<div class="radio">
										<label><input type="radio" name="r1" value="standard application">standard application</label>
										</div>
										<div class="radio">
										<label><input type="radio" name="r1" value="Exempted from standard application">Exempted from standard application</label>
										</div>
										<div class="radio">
										<label><input type="radio" name="r1" value="Expedited application">Expedited application</label>
										</div>
										</div>
										<div class="form-group">
										<label>Principal investigator *</label>
										<p>An individual performing a study is called a Principal Investigator. In cases where more than one individual is performing a study, one of the researchers must be designated as the Principal Investigator. The group of researchers makes this choice. The name that appears in #2 should be in the official format used as registered at Gannon University, i.e. “Elizabeth Josephine White” rather than Betty Jo White or B. J. White. </p>
										<input type="text" class="form-control" id="usr" name="Principal_ans" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Title of Research Study Proposal: *</label>
										<p>Type the full name of proposal. See APA Manual of Style for naming conventions.</p>
										<input type="text" class="form-control" id="usr" name="study_propos" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Investigator mailing address: *</label>
										<p>Type the full name of proposal. See APA Manual of Style for naming conventions.</p>
										<input type="text" class="form-control" id="usr" name="inves_mail" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Investigator telephone *</label>
										<input type="text" class="form-control" id="usr" name="inves_tele" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Email*</label>
										<input type="text" class="form-control" id="usr" name="email_invester" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label for="sel1">Status*</label>
										<select class="form-control" id="sel1" name="status">
										<option>choose</option>
										<option value="approved">student</option>
										<option value="Rejected">Faculty</option>
                                                                                <option value="Approved with condition">Faculty</option>
										</select>
										</div>
										<div class="form-group">
										<label>Sponsor name and degree*</label>
										<input type="text" class="form-control" id="usr" name="Sponsor_name" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Faculty sponsor’s office*</label>
										<input type="text" class="form-control" id="usr" name="fac_office" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Mailing address*</label>
										<input type="text" class="form-control" id="usr" name="address" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>Telephone</label>
										<input type="text" class="form-control" id="usr" name="telephone" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label>E-mail</label>
										<input type="text" class="form-control" id="usr" name="email" placeholder="Enter Answer">
										</div>
										<div class="form-group">
										<label for="sel1">Are there co-investigators? </label>
										<select class="form-control" id="sel1" name="co-investigators">
										<option>choose</option>
										<option value="yes">yes</option>
										<option value="no">no</option>
										</select>
									
									</div>
										<input type="button" name="next" class="next_btn" value="Next" />
										<input type="submit" name="s1" class="submit_btn" value="save" /> 
										<BR/>	<BR/>	<BR/>
	
	</fieldset>
	<fieldset>
		<h2 class="title">Step-2</h2>
									<div class="form-group">
									<label>CO INVESTIGATORS names</label>
									<input type="text" class="form-control" id="usr" name="co_invet" placeholder="Enter Answer">
									</div>
									<div class="form-group">
									<label>Co investigator mailing address</label>
									<input type="text" class="form-control" id="usr" name="co_invet_mail" placeholder="Enter Answer">
									</div>

									<div class="form-group">
									<label>Co investigator email address</label>
									<input type="text" class="form-control" id="usr" name="co_invet_email" placeholder="Enter Answer"/>
									</div>

									<div class="form-group">
									<label>co investigator telephone number</label>
									<input type="text" class="form-control" id="usr" name="co_invet_tele" placeholder="Enter Answer"/>
									</div>
									<div class="form-group">
									<label>Please select applicable categories. This research study proposal is: </label>
									<div class="form-group">
									<input type="checkbox" name="chk1[]" value="A new grant/contract">A new grant/contract
									</div>
									<div class="form-group">
									<input type="checkbox"  name="chk1[]" value="A dissertation or thesis">A dissertation or thesis
									</div>
									<div class="form-group">
									<input type="checkbox" name="chk1[]" value="An amendment to an existing study">An amendment to an existing study
									</div>
									<div class="form-group">
									<input type="checkbox" name="chk1[] value="A graduate research proposal">A graduate research proposal
									</div>
									<div class="form-group">
									<input type="checkbox"   name="chk1[]" value="A graduate research proposal">An addendum to an existing study
									</div>
									<div class="form-group">
									<input type="checkbox"  name="chk1[]" value="A graduate research proposal"> An independent study
									</div>
									<div class="form-group">
									<input type="checkbox" value="A class project" name="chk1[]"> A class project
									</div>
									<div class="form-group">
									<input type="checkbox"  name="chk1[]" value="An undergraduate research proposal"/> An undergraduate research proposal
									</div>
									</div>
									<div class="form-group">
									<label>If the proposal is a grant application, indicate the funding agency</label>
									<input type="text" class="form-control" id="usr" name="grnt_app" placeholder="Enter Answer">
									</div>
									<div class="form-group">
									<label for="inputEmail">Is notification of IRB approval required by the granting agency</label><BR/>
									<input type="radio" name="r2" value="yes">yes<BR/>
									<input type="radio" name="r2" value="no">No<BR/>
									<input type="radio" name="r2" value="Expedited application">Expedited application
									</div>

									<div class="form-group">
									<label>If the proposal is a grant application, indicate the funding agency</label>
									<input type="text" class="form-control" id="usr" name="grnt_app" placeholder="Enter Answer">
									</div>
									<div class="form-group">
									<label>Data gathering start date:</label>
									<input type="text" class="form-control" id="usr" name="start_dat" placeholder="dd/MM/YY"/>
									</div>

									<div class="form-group">
									<label>Data gathering end date:</label>
									<input type="text" class="form-control" id="usr" name="end_date" placeholder="dd/MM/YY">
									</div>
									<div class="form-group">
									<label for="inputEmail">What is the projected study duration?</label><BR/>
									<input type="radio" name="r3" value="Fewer than 13 months from application date">Fewer than 13 months from application date<BR/>
									<input type="radio" name="r3" value="More than 13 months from application date">More than 13 months from application date<BR/>
									</div>
		<input type="button" name="previous" class="pre_btn" value="Previous" />
		<input type="button" name="next" class="next_btn" value="Next" />
		<BR/><BR/><BR/>
	</fieldset>
	<fieldset>
		<h2 class="title">Step 3</h2>
	<div class="form-group">
			<label for="inputEmail">Electrical equipment will be used.</label>
			<div class="radio">
			<label><input type="radio" name="r11" value="yes">YES</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r11" value="no">No</label>
			</div>
			</div>
			<div class="form-group">
			<label for="inputEmail">Subjects will be tape recorded, photographed, or videotaped.</label>
			<div class="radio">
			<label><input type="radio" name="r12" value="yes">YES</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r12" value="no">No</label>
			</div>
			</div>
			<div class="form-group">
			<label for="inputEmail">Does any part of this activity have the potential for coercion of the subject?</label>
			<p>If yes, explain why coercion is necessary and describe the methods to be used to protect subjects. Explain why coercion is necessary (as opposed to convenient) for this study. Include methods and timetable for debriefing, de-hoaxing, or desensitizing. If such a plan will not be used, explain why</p>
			<div class="radio">
			<label><input type="radio" name="r13" value="yes">YES</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r13" value="no">No</label>
			</div>
			</div>
			<div class="form-group">
			<label for="inputEmail">Are the subjects exposed to deception?</label>
			<p>If yes, explain why coercion is necessary and describe the methods to be used to protect subjects. Explain why coercion is necessary (as opposed to convenient) for this study. Include methods and timetable for debriefing, de-hoaxing, or desensitizing. If such a plan will not be used, explain why. Include a time table for any de-hoaxing</p>
			<div class="radio">
			<label><input type="radio" name="r14" value="yes">YES</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r14" value="no">No</label>
			</div>
			</div>
			<div class="form-group">
			<label for="inputEmail">What possible benefits could the subject derive from participation in the proposed research study?</label>
			<p>Describe any benefits to the subject or to others which may be reasonably expected from the research (PLEASE NOTE: Money or other compensation for participation is NOT considered to be a benefit, but rather a compensation for research-related inconveniences.) The answer to this question should also appear on the informed consent documents that accompany the application for review.</p>
			<input type="text" class="form-control" id="usr" name="benefits" placeholder="Enter Answer">
			</div>
			<div class="form-group">
			<label for="inputEmail">What contributions to general knowledge in the field of inquiry or possible benefits could be derived from the research?</label>
			<p>This question should be answered on the application. The answers should also appear on the informed consent documents that accompany the application for review.</p>
			<input type="text" class="form-control" id="usr" name="research" placeholder="Enter Answer">
			</div>
			<div class="form-group">
			<label for="inputEmail">If subjects will be rewarded or compensated, state the amount, types, and timetable for compensation. If subjects are recruited from Gannon University classes, state whether students are receiving course credit (regular or extra credit) and state alternatives offered to students who do not wish to participate.</label>
			<div class="radio">
			<label><input type="radio" name="r15" value="yes">YES</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r15" value="no">No</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r15" value="other">other</label>
			</div>
			</div>
			<div class="form-group">
			<label for="inputEmail">Choose one</label>
			“Minimal risk” means the probability and magnitude of harm or discomfort anticipated in the research are not greater than those encountered in daily life. Benefit is something of value to the research subject or something that will contribute to generalizable knowledge
			<div class="radio">
			<label><input type="radio" name="r18" value="The research involves no more than minimal risk.">The research involves no more than minimal risk.</label>
			</div>
			<div class="radio">
			<label><input type="radio" name="r18" value="The research involves more than minimal risk">The research involves more than minimal risk.</label>
			</div>
			</div>
		<textarea name="address" placeholder="Address"></textarea><br/>

		<div class="form-group">
		<label>PURPOSE: What is the purpose of the research? State the hypothesis or research question.</label>
		<input type="text" class="form-control" id="usr" name="purpose" placeholder="Enter Answer">
		</div>

		<div class="form-group">
		<label>METHODOLOGY: How will the research be conducted? *</label>
		<P>As briefly as possible, summarize the steps taken in the study, concentrating on the treatment of the participants. This may require more than one page of explanation. IRB is concerned with human subjects. Although part of the methodology, statistical formulas for evaluation of data are not directly related to IRB concerns. State how subjects will be chosen, recruited, and treated. Extensive references are not to be included. </P>
		<input type="text" class="form-control" id="usr" name="methodology" placeholder="Enter Answer">
		</div>
		<div class="form-group">
		<label for="inputEmail">SUBJECTS: Who will be the research subjects? Please select one.</label>
		<p>Adult members of the population at large include individuals who may belong to vulnerable populations or who may become a member of a vulnerable population during the study i.e. loose a job or become pregnant. If vulnerable populations are NOT the focus of the study, X the first choice. If the proposed study uses de-identified data, determining the vulnerability status of subject may not be possible.</p>
		<div class="radio">
		<label><input type="radio" name="r4" value="Research subjects will be selected from adult members of the population at large." >Research subjects will be selected from adult members of the population at large.</label>
		</div>
		<div class="radio">
		<label><input type="radio" name="r4" value="Research subjects will be selected from vulnerable populations.">Research subjects will be selected from vulnerable populations.</label>
		</div>
		<div class="radio">
		<label><input type="radio" name="r4" value="Research subjects will be selected from de-identified data.">Research subjects will be selected from de-identified data.</label>
		</div>
		</div>
		<div class="form-group">
		<label>If research subjects will be selected from a vulnerable population, please select all that apply:</label>
		<input type="checkbox" name="chk9[]" value="Minors under age of 18"> Minors under age of 18<br/>
		<input type="checkbox" name="chk9[]" value="Senior Citizens (over 65)">Senior Citizens (over 65)<br/>
		<input type="checkbox" name="chk9[]" value="Terminally Ill"> Terminally Ill<br/>
		<input type="checkbox" name="chk9[]" value="Students"> Students<bt/>
		<input type="checkbox" name="chk9[]" value="Prisoners"> Prisoners<br/>
		<input type="checkbox"  name="chk9[]"  value="Cognitively Impaired"> Cognitively Impaired<br/>
		<input type="checkbox" name="chk9[]"  value="Non-English Speakers"> Non-English Speakers<br/>
		<input type="checkbox" name="chk9[]" value="Mentally/Physically Disabled"> Mentally/Physically Disabled<br/>
		<input type="checkbox"  name="chk9[]" value="Pregnant Women"> Pregnant Women<br/>
		<input type="checkbox" name="chk9[]" value="Institutional Residents"> Institutional Residents<br/>
		<input type="checkbox" name="chk9[]" value="Employees"> Employees<br/>
		<input type="checkbox" name="chk9[]" value="Economically Disadvantaged"> Economically Disadvantaged<br/>
		</div>
		<div class="form-group">
		<label>State the rationale for using vulnerable populations. What safeguards will be used to protect members of a vulnerable population?</label>
		<input type="text" class="form-control" id="usr" name="population" placeholder="Enter Answer">
		</div>
		<div class="form-group">
		<label>What is the approximate total number of subjects to be recruited?</label>
		<input type="text" class="form-control" id="usr" name="recruited" placeholder="Enter Answer">
		</div>
		<div class="form-group">
		<label>How will the subjects be recruited/solicited? Please check all that apply.</label>
		<input type="checkbox" name="chk5[]" value="A class project"> Advertisements<br/>
		<input type="checkbox" name="chk5[]" value="A class project">Letters<br/>
		<input type="checkbox" name="chk5[]" value="A class project"> Random Calls<br/>
		<input type="checkbox" name="chk5[]" value="A class project"> Notices<br/>
		<input type="checkbox" name="chk5[]" value="A class project"> Direct Solicitation<br/>
		</div>
		<div class="form-group">
		<label for="inputEmail">With respect to any of the above criteria, subjects are at risk.</label>
		<p>A research subject is considered to be at risk if he or she may be exposed through the procedures of the proposed research study to the possibility of physical or mental harm, coercion, deceit or loss of privacy. Placing subjects at risk of harm could include (a) administration of unusual physical exertion, (b) deceit, (c) public disclosure of private information, (d) embarrassment or humiliation or (e) mental anguish. Coercion may be present when the potential subjects do not feel comfortable exercising their right to decline participation, as in cases where the researcher has power over the subjects</p>
		<div class="radio">
		<label><input type="radio" value="yes" name="r6">YES</label>
		</div>
		<div class="radio">
		<label><input type="radio" value="no" name="r6">No</label>
		</div>
		</div>
		<div class="form-group">
		<label for="inputEmail">Experimental drugs will be used.</label>
		<div class="radio">
		<label><input type="radio" name="r7"  value="yes">YES</label>
		</div>
		<div class="radio">
		<label><input type="radio" name="r7" value="no">No</label>
		</div>
		</div> 
		<div class="form-group">
		<label for="inputEmail">Potential for a medical problem exists.</label>
		<div class="radio">
		<label><input type="radio" name="r8" value="yes">YES</label>
		</div>
		<div class="radio">
		<label><input type="radio" name="r8" value="no">No</label>
		</div>
		</div>
		<div class="form-group">
		<label for="inputEmail">Subjects may experience physical discomfort greater than in everyday life.</label>
		<div class="radio">
		<label><input type="radio" name="r9">YES</label>
		</div>
		<div class="radio">
		<label><input type="radio" name="r9">No</label>
		</div>
		</div>
		<div class="form-group">
		<label for="inputEmail">Subjects may experience mental discomfort greater than in everyday life.</label>
		<div class="radio">
		<label><input type="radio" name="r10" value="yes">YES</label>
		</div>
		<div class="radio">
		<label><input type="radio" name="r10" value="no">No</label>
		</div>
		</div>
		<input type="hidden" name="userid" value="<?php echo $_SESSION['email'];?>">
				<input type="button" class="pre_btn" value="Previous" />
				<input type="submit" name="s2" class="submit_btn" value="Submit" /><BR/><BR/><BR/>
			</fieldset>
</form>
</div>
</div>
</div>	

 

				 

	<?php
	include('footer.php');

	?>