<?php

include('../connection.php');
include('header.php');
error_reporting(0);
$id=$_REQUEST['id'];
$result=mysql_query("select * from review where rid='$id'");
$res=mysql_fetch_array($result);
//print_r($res);
?>
<div id="page-wrapper">
<div class="container">
<div class="col-md-8">
  
          <div class="form-group">
              <label for="inputEmail">Type of review</label>
               <input type="text"  class="form-control" id="usr"  name="Type of review" value="<?php echo $res['Type_of_review'];?>">
                
          </div>
              <div class="form-group">
                  <label>Principal investigator *</label>
                      
                    <input type="text" class="form-control" id="usr" name="Principal_ans" value="<?php echo $res['Principal_investigator'];?>">
              </div>
              
               <div class="form-group">
                  <label>Title of Research Study Proposal: *</label>
                        <p>Type the full name of proposal. See APA Manual of Style for naming conventions.</p>
                        <input type="text" class="form-control" id="usr" name="study_propos" value="<?php echo $res['Title_of_Research_Study_Proposal'];?>">
              </div>
              
              <div class="form-group">
                  <label>Investigator mailing address: *</label>
                 
                  <input type="text" class="form-control" id="usr" name="inves_mail" value="<?php echo $res['Investigator_mailing'];?>">
              </div>
             
              <div class="form-group">
                <label>Investigator telephone *</label>
                <input type="text" class="form-control" id="usr" name="inves_tele"  value="<?php echo $res['Investigator_telephone'];?>">
              </div>
                <div class="form-group">
                <label>Email*</label>
                <input type="text" class="form-control" id="usr" name="email_invester" value="<?php echo $res['Email'];?>">
              </div>
              <div class="form-group">
              <label for="sel1">Status*</label>
               <input type="text" class="form-control" id="usr" name="status" value="<?php echo $res['Status'];?>">
              
              </div>
               <div class="form-group">
                <label>Sponsor name and degree*</label>
                <input type="text" class="form-control" id="usr" name="Sponsor_name" value="<?php echo $res['Sponsorname_and_degree'];?>">
              </div>
            <div class="form-group">
                <label>Faculty sponsor’s office*</label>
                <input type="text" class="form-control" id="usr" name="fac_office" value="<?php echo $res['Faculty_sponsor_office'];?>"">
            </div>
               <div class="form-group">
                <label>Mailing address*</label>
                <input type="text" class="form-control" id="usr" name="address" value="<?php echo $res['Mailing_address'];?>">
             </div>
                 <div class="form-group">
                  <label>Telephone</label>
                  <input type="text" class="form-control" id="usr" name="telephone" value="<?php echo $res['Telephone'];?>">
               </div>
                <div class="form-group">
                  <label>E-mail</label>
                  <input type="text" class="form-control" id="usr" name="email" value="<?php echo $res['E-mail'];?>">
               </div>
              <div class="form-group">
                  <label for="sel1">Are there co-investigators? </label>
                  <input type="text" class="form-control" id="usr" name="co-investigators" value="<?php echo $res['Are_there_co-investigators'];?>">
              </div>
              <div class="form-group">
                  <label>CO INVESTIGATORS names</label>
                  <input type="text" class="form-control" id="usr" name="co_invet" value="<?php echo $res['CO_INVESTIGATORS_names'];?>" >
              </div>
              
                <div class="form-group">
                  <label>Co investigator mailing address</label>
                  <input type="text" class="form-control" id="usr" name="co_invet_mail" value="<?php echo $res['Co_investigator_mailing_address'];?>">
              </div>
                 <div class="form-group">
                 
                  <label>Co investigator email address</label>
                  <input type="text" class="form-control" id="usr" name="co_invet_email" value="<?php echo 
                  $res[16]; ?>">
              </div>
                 <div class="form-group">
                  <label>co investigator telephone number</label>
                  <input type="text" class="form-control" id="usr" name="co_invet_tele" value="<?php echo 
                  $res[17]; ?>">
               </div>
                <div class="form-group">
              <label>Please select applicable categories. This research study proposal is: </label>
              <textarea class="form-control" rows="5" id="comment" value="chk1"><?php echo $res[18];?></textarea>
                
                </div>
                  
      <div class="form-group">
                    <label>If the proposal is a grant application, indicate the funding agency</label>
                    <input type="text" class="form-control" id="usr" name="grnt_app" value="<?php echo 
                  $res[19]; ?>">
                </div>
                  <div class="form-group">
                <label for="inputEmail">Is notification of IRB approval required by the granting agency</label><BR/>
                 <input type="text" class="form-control" id="usr" name="irb_approval" value="<?php echo 
                  $res[20]; ?>">
                      
                    
            </div>

                <div class="form-group">
                    <label>If the proposal is a grant application, indicate the funding agency</label>
                    <input type="text" class="form-control" id="usr" name="grnt_app"  value="<?php echo 
                  $res[21]; ?>">
                </div>
                   <div class="form-group">
                    <label>Data gathering start date:</label>
                    <input type="text" class="form-control" id="usr" name="start_dat" value="<?php echo $res['start_date'];?>">
                </div>
                   <div class="form-group">
                    <label>Data gathering end date:</label>
                    <input type="text" class="form-control" id="usr" name="end_date" value="<?php echo $res['end_date'];?>">
                   </div>
                <div class="form-group">
                  <label for="inputEmail">What is the projected study duration?</label><BR/>
                  <input type="text" class="form-control" id="usr" name="end_date" value="<?php echo $res['study_duration'];?>">
                   
                
                <div class="form-group">
                    <label>PURPOSE: What is the purpose of the research? State the hypothesis or research question.</label>
                    <input type="text" class="form-control" id="usr" name="purpose" value="<?php echo $res['esearch_qution'];?>">
               </div>

                  <div class="form-group">
                    <label>METHODOLOGY: How will the research be conducted? *</label>
                    <input type="text" class="form-control" id="usr" name="methodology" value="<?php echo $res['METHODOLOGY'];?>">
                   </div>
                      <div class="form-group">
		                <label for="inputEmail">SUBJECTS: Who will be the research subjects? Please select one.</label>
		               <input type="text" class="form-control" id="usr" name="methodology" value="<?php echo $res['SUBJECTS'];?>">
               		 </div>

                  <div class="form-group">
                <label>If research subjects will be selected from a vulnerable population, please select all that apply:</label>
            <textarea class="form-control" rows="5" id="comment" value="chk1"><?php echo $res['vulnerable_population'];?></textarea>
                 
               </div>
                 <div class="form-group">
                    <label>State the rationale for using vulnerable populations. What safeguards will be used to protect members of a vulnerable population?</label>
                    <input type="text" class="form-control" id="usr" name="population" value="<?php echo $res['rationale'];?>">
                  </div>
                  <div class="form-group">
                      <label>What is the approximate total number of subjects to be recruited?</label>
                      <input type="text" class="form-control" id="usr" name="recruited"  value="<?php echo $res['number_of_subjects'];?>">
                  </div>
                  <div class="form-group">
                    <label>How will the subjects be recruited/solicited? Please check all that apply.</label>
                     <textarea class="form-control" rows="5" id="comment" value="chk1"><?php echo $res['recruited'];?></textarea>
                </div>
                  <div class="form-group">
                  <label for="inputEmail">With respect to any of the above criteria, subjects are at risk.</label>
                  </div>
                 <div class="form-group">
                  <label for="inputEmail">Experimental drugs will be used.</label>
                  <input type="text" class="form-control" id="usr" name="drugs"  value="<?php echo $res[31];?>">
                </div>
                 <div class="form-group">
                  <label for="inputEmail">Potential for a medical problem exists.</label>
                   <input type="text" class="form-control" id="usr" name="medical"  value="<?php echo $res[32];?>">
                  
                </div>

              <div class="form-group">
                <label for="inputEmail">Subjects may experience physical discomfort greater than in everyday life.</label>
                 <input type="text" class="form-control" id="usr" name="physical"  value="<?php echo $res[33];?>">
              </div>

            <div class="form-group">
              <label for="inputEmail">Subjects may experience mental discomfort greater than in everyday life.</label>
              <input type="text" class="form-control" id="usr" name="mental"  value="<?php echo $res[34];?>">
            </div>
            <div class="form-group">
              <label for="inputEmail">Electrical equipment will be used.</label>
              <input type="text" class="form-control" id="usr" name="Electrical"  value="<?php echo $res[35];?>">
            </div>
            <div class="form-group">
              <label for="inputEmail">Subjects will be tape recorded, photographed, or videotaped.</label>
              <input type="text" class="form-control" id="usr" name="photographed"  value="<?php echo $res[36];?>">
              
            </div>

            <div class="form-group">
            <label for="inputEmail">Does any part of this activity have the potential for coercion of the subject?</label>
            <input type="text" class="form-control" id="usr" name="coercion"  value="<?php echo $res[37];?>">
            </div>
             <div class="form-group">
            <label for="inputEmail">Are the subjects exposed to deception?</label>
            <input type="text" class="form-control" id="usr" name="exposed"  value="<?php echo $res[38];?>">
            
            </div>

             <div class="form-group">
            <label for="inputEmail">What possible benefits could the subject derive from participation in the proposed research study?</label>
            
            <input type="text" class="form-control" id="usr" name="benefits" value="<?php echo $res[39];?>">
            </div>

            <div class="form-group">
            <label for="inputEmail">What contributions to general knowledge in the field of inquiry or possible benefits could be derived from the research?</label>
            
            <input type="text" class="form-control" id="usr" name="research" value="<?php echo $res[41];?>"/>
            </div>

            <div class="form-group">
            <label for="inputEmail">If subjects will be rewarded or compensated, state the amount, types, and timetable for compensation. If subjects are recruited from Gannon University classes, state whether students are receiving course credit (regular or extra credit) and state alternatives offered to students who do not wish to participate.</label>
            <input type="text" class="form-control" id="usr" name="rewarded" value="<?php echo $res[42];?>"/>
            </div>
            <div class="form-group">
            <label for="inputEmail">Choose one</label>
           <input type="text" class="form-control" id="usr" name="Choose_one"  value="<?php echo $res['Choose one'];?>">
            </div>
           <!-- <form action="submitreview.php" method="post">-->
            <input type="hidden"  name="reviewid" value="<?php echo $res[0];?>"/>
            <input type="hidden"  name="userid" value="<?php echo $res['userid'];?>"/>
           <!--  <div class="form-group">
            <label>ERROR send report irb member-</label>
            <textarea id="comment" class="form-control" rows="5" name="error"></textarea>
            </div> -->
            <button type="submit" class="btn btn-primary" name="s1">back</button>
              <br/>
              <br/>
              <br/>
            </form>
            </div>
            <div class="col-md-2">
            </div>
    </div>
    </div>

         <?php

include('footer.php');
         ?>
