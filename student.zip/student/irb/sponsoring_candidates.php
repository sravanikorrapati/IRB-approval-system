<?php
include('header.php');
?>
<?php
 $idfac=$result[0];

?>


<div id="page-wrapper">
				<div class="graphs">
				<br/>
					<h3 class="blank1"> view  all   Sponsorship Request</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
				<table class="table">
						  <thead>
							<tr>
							  <th>id </th>

							  <th>Student name</th>
							  <th>faculty name</th>
							  <th>question</th>
							  <th>description</th>
							 
							  <th>status</th>
							  <th>Delete</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
								$sql="SELECT * FROM  `sponsorship_irb` where irb_id='$idfac' ";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{
									//print_r($result);
								?>
							<tr class="active">
							  <th scope="row"><?php echo $result['siid']; ?> </th>
							 
							  <td><?php $fname= $result['sid'];

							  			$sql=mysql_query("select * from user where id='$fname'");
							  			$row=mysql_fetch_array($sql);
							  			echo $row[1];

							  ?></td>
							   <td>    <?php $fname= $result['fid'];
							  			$sql=mysql_query("select * from faculty where fid='$fname'");
							  			$row=mysql_fetch_array($sql);
							  			echo $row[1];?> </td>
							 
							  <td><?php echo $result['question'];?></td>
							  <td><?php echo $result['description'];?></td>

							
							   		<td><?php  $result['status'];
							   		if($result['status']==0)
							   		{

							   		echo "<a href='approve.php?id=$result[0]' title='click to accept status'>pending</a>";


							   		}
							   		else
							   		{
							   			echo "approve ";

							   		}

							   		?></td>



							  <!-- <td><a href="student_edit.php?id=<?php echo $result[0];?>">edit</a></td> -->
							  <td><a href="sponsorship_delete.php?id=<?php echo $result[0];?>">Delete</a></td>
							  
							</tr>																						<?php		
								}
								?>
						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>
					   












<?php

include('footer.php');
?>