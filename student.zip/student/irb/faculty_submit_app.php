<?php
include('header.php');

?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Faculty submit application</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						  <thead>
							<tr>
								  <th>Review Id</th>
								  <th>faculty name</th>
								  <th> status</th>
								  <th>Type_of_review</th>
								  <th>Principal investigator</th>
								  <th>view more</th>
                                                                  <th>Decision</th>
								  
							</tr>
						  </thead>
						  <tbody>
								<?php
								$sql="SELECT * FROM `review_faculty`";
								$sql1=mysql_query($sql);
								while($result=mysql_fetch_array($sql1))
								{
								?>
							<tr class="active">
							  <td><?php echo $result[0];?></td>
							  <td><?php $user=$result['faculty_id'];

							  		$sql=mysql_query("select * from faculty where fid='$user'");
							  		$user=mysql_fetch_array($sql);
							  		echo $user[1];


							  ?>
							  </td>
							  <td><?php echo $result['Status'];?></td>
							  <td><?php echo $result['Principal_investigator'];?></td>
							  <td><?php echo $result['Type_of_review'];?></td>
							  <td><a href="faculty_view_submit_app.php?id=<?php echo $result[0];?>">view more </a>
                                                          <td><?php echo <label> </label>
                                                              <option value ="approve"></option?></td>
							   	
							</tr>	
							<?php		
								}
								?>
						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>			   
<?php
include('footer.php');
?>