
<!DOCTYPE HTML>
<html>
<head>
<title>IRB</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Easy Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="../css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="../css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<!-- lined-icons -->
<link rel="stylesheet" href="../css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<!-- chart -->
<script src="../js/Chart.js"></script>
<!-- //chart -->
<!--animate-->
<link href="../css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="../js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!----webfonts--->
<link href='//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<!---//webfonts---> 
 <!-- Meters graphs -->
<script src="../js/jquery-1.10.2.min.js"></script>
<!-- Placed js at the end of the document so the pages load faster -->

</head> 
   
 <body class="sign-in-up">
 <div class="jumbotron">
  <div class="container">
  <div class="col-sm-3">
    <img src="../images/logo.png" height="150px" />
      <h4>Believe in Possibilities</h4>

  </div>  
    <div class="col-sm-6 left">
  
   <br/>
   <br/>
   <h2 class="heading">Welcome to IRB Home Page</h2>
  </div>   
    <div class="col-sm-3">
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search .." title="Type in a name">
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

    
  </div>     

    
  </div>

</div>
 <div class="container">
 	<div class="col-sm-6">
				<div class="graphs">
					<div class="">
						<div class="sign-in-form-top">
							<p>Login to IRB Memeber</p>
						</div>
						<div class="signin">
							<div class="signin-rit">
								
								
								<div class="clearfix"> </div>
							</div>
							<form action="login.php" method="post">
							<div class="log-input">
								<div class="log-input-left">
								   <input type="text" class="user" name="username" placeholder="Enter your E-mail" required=""/>
								</div>
								<span class="checkbox2">
									 <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i> </i></label>
								</span>
								<div class="clearfix"> </div>
							</div>
							<div class="log-input">
								<div class="log-input-left">
								   <input type="password" class="lock" name="password" placeholder="Enter your password" required=""/>
								</div>
								<span class="checkbox2">
									 <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i> </i></label>
								</span>
								<div class="clearfix"> </div>
							</div>
							<input type="submit" value="Login to your account">
						</form>	 
						</div>
						
					</div>
				</div>
			
		<!--footer section start-->

        <!--footer section end-->
</div>
<div class="col-sm-6">
    <section>
			<div id="page-wrapper" class="sign-in-wrapper">
				<div class="graphs">
					<div class="">
						<h3>Register Here</h3>
						
						<h5>Personal Information</h5>
					<form action="register.php" method="post">
						<div class="sign-u">
						
							<div class="sign-up1">
								<h4>First Name* :</h4>
							</div>
							<div class="sign-up2">
									<input type="text" placeholder="Enter name" required=" " name="firstname"/>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="sign-u">
							<div class="sign-up1">
								<h4>Last Name* :</h4>
							</div>
							<div class="sign-up2">
									<input type="text" placeholder="Enter your last name" required=" " name="lastname"/>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="sign-u">
							<div class="sign-up1">
								<h4>Email Address* :</h4>
							</div>
							<div class="sign-up2">
						
									<input type="text" placeholder="Enter your email" required=" " name="email"/>
								
							</div>
							<div class="clearfix"> </div>
						</div>
						<h6>Login Information</h6>
						<div class="sign-u">
							<div class="sign-up1">
								<h4>Password* :</h4>
							</div>
							<script type="text/javascript">
								function show()
								{
									//alert("hello");
									if(document.getElementById("pass").value!=document.getElementById("cpass").value)
									{

										alert("password not match");
										return false;
									}
								}
							</script>
							<div class="sign-up2">
									<input type="password" placeholder="*******" required=" " id="pass" name="password"/>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="sign-u">
							<div class="sign-up1">
								<h4>Confirm Password* :</h4>
							</div>
							<div class="sign-up2">
									<input type="password" required=" " id="cpass" placeholder="*******"/>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="sub_home">
							<div class="sub_home_left">
									<input type="submit" value="Submit" onclick=" return show()">
						</div>
					</form>	
							<div class="sub_home_right">
								<p>Go Back to <a href="../index.php">Home</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
			</div>
		<!--footer section start-->
        <!--footer section end-->
</div>
</div>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>