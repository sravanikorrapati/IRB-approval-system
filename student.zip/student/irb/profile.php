
<style>
.main-content.main-content5 > div {
    text-align: center;
}
</style>
<?php
include('header.php');
 $email=$_SESSION['email'];
 $sql=mysql_query("select * from irb where username='$email'");
 $result=mysql_fetch_array($sql);
 $userid=$result[0];
?>
			<div id="page-wrapper">
				<div class="graphs">
				<br/>
					<h3 class="blank1">Hi <?php echo $result['username'];?> welcome to IRB Member
					</h3>
					<div class="graph_box">
						<div class="col-md-4">
							<div class="dropdown">
							<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">View assigned Forms
							</button>
							<ul class="dropdown-menu">
							<li><a href="view_review_request_student.php"">apply review student</a></li>
							<li><a href="view_review_request_faculty.php"">apply review faculty</a></li>
							</ul>
						  </div> 
						</div>
						<div class="col-md-4">
								<div class="dropdown">
									<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Post Decision
									</button>
									<ul class="dropdown-menu">
										<li><a href="submit_app.php">view apply student</a></li>
										<li><a href="faculty_submit_app.php">apply faculty</a></li>
									</ul>
							  </div> 
								<!-- <ul class="dropdown-menu">
									<button class="btn btn-primary" type="button" >Post Decision
									</button>
									<li><a href="view_review_request_student.php"">apply review student</a></li>
									<li><a href="view_review_request_faculty.php"">apply review faculty</a></li>
								</ul> -->
						</div>
						<div class="col-md-4">
							<a href="calendar.php"><button class="btn btn-primary" type="button">Scheduled meetings
							</button></a>
						</div>
					</div>
						<div class="clearfix"> </div>
					</div>
					<div class="container">
					<br/>
					<br/>
						<div class="col-md-4">
						
								
								<a href="semd_massage_admin.php"><button class="btn btn-primary" type="button">send email to admin
							</button></a>
						</div>
						<div class="col-md-4">
								<a href="sponsoring_candidates.php"><button class="btn btn-primary" type="button" >view  sponsoring candidates
							</button></a>
							</div>
								
						
							<div class="col-md-4">
								
										<!-- <a href="sponsoring_candidates.php"><button class="btn btn-primary" type="button" >sponsoring candidates
							</button></a> -->
								</div>
							
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
		</div>
		<?php
		include('footer.php');?>
		