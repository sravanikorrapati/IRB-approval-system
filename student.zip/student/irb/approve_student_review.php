<?php
	include('../connection.php');
		$appid=$_REQUEST['id'];

		$sql="UPDATE `student`.`admin_send_irb_student` SET `status` = '1' WHERE `request_id` ='$appid';";
		$res=mysql_query($sql);
		if($res)
			{
				echo "<script>alert('Accept request'); window.location='view_review_request_student.php'</script>";
			}
			else
			{
				echo "<script>alert('Accept request error'); window.location='view_review_request_student.php'</script>";
			}

?>