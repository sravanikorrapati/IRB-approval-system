<?php

include('../connection.php');

$firstname=$_REQUEST['firstname'];
$lastname=$_REQUEST['lastname'];
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];

$sql=mysql_query("INSERT INTO  `irb` (
`id` ,
`username` ,
`password` ,
`first_name` ,
`last_name`
)
VALUES (
NULL , '$email','$password', '$firstname','$lastname'
)");

 

if($sql)
{
	

	
	echo "<script> alert('you are register'); window.location='index.php';</script>";
	
	
	
}
else
{
	
	echo "<script> alert('you not register');</script>";
	
	
}
?>


