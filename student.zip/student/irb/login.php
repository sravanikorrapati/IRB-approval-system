<?php
include('../connection.php');
session_start();

$email=$_REQUEST['username'];
$password=$_REQUEST['password'];

$sql=mysql_query("SELECT * FROM `irb` WHERE  username='$email' AND password='$password'");


if(mysql_affected_rows()>0)
{
	
	$_SESSION['email']=$email;
	
	echo "<script>alert('login suessfully'); window.location='profile.php';</script>";
	
}
else
{
	
	echo "<script>alert('login error'); 
	
				window.location='index.php'</script>";
	
	
}
	



?>