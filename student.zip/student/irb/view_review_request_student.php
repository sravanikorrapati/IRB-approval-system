<?php
include('header.php');
?>
<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Assign student  review list</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
						 <table class="table">
						  <thead>
							<tr>
								  <th> Id</th>
								  <th>student name</th>
								  <th>description </th>
								  <th>view review</th>
								  <th>status</th>
								  
							</tr>
						  </thead>
						  <tbody>
								<?php
									$irbid=$result[0];
									$sql="SELECT * FROM `admin_send_irb_student` where irb_member='$irbid'";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
									{
								?>
							<tr class="active">
							  <td><?php echo $result[0];?></td>
							  <td><?php $res=$result[1];
							  $res1=mysql_fetch_array(mysql_query("select * from user where id='$res'"));
							  echo $res1[1];
							  ?></td>
							  <td><?php echo $result[2];?></td>
							  <td><a href="view_student_review.php?id=<?php echo $result['review_id'];?>">view review</a></td> 
							  <td><?php  $result['status'];
							  if($result['status']==0)
								  {
								  	echo "<a href='approve_student_review.php?id=$result[0]' title='click to accept status'>accept Request</a>";
								  }
								  else
								  {
								  	echo "approve";

								  }
							  ?></td>
							<?php		
								}
							?>

						 </tbody>
						</table>
					   </div>
					</div>
				</div>
			</div>		


   
<?php
include('footer.php');
?>
