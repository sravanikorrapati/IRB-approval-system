<?php

include('header.php');
?>

<div id="page-wrapper">
				<div class="graphs">
					<h3 class="blank1">Student submit application</h3>
					 <div class="xs tabls">
						<div class="bs-example4" data-example-id="contextual-table">
                                                 <form class="regform" action="decision.php" method ="get">
						 <table class="table">
						 	<thead>
							<tr>
								<th>Review Id</th>
								<th>student name</th>
								<th>student status</th>
								<th>Principal investigator</th>
								<th>Type of review</th>
								<th>view more</th>
                                                                <th>Decision</th>
                                                                <th>submit decision</th>
							</tr>
						  </thead>
						  <tbody>
								<?php
									$sql="SELECT * FROM `review`";
									$sql1=mysql_query($sql);
									while($result=mysql_fetch_array($sql1))
								{
								?>

							<tr class="active">
								<td><?php echo $result[0];?></td>
								<td><?php echo $result['userid'];?></td>
								<td><?php echo $result['Status'];?></td>
								<td><?php echo $result['Principal_investigator'];?></td>
								<td><?php echo $result['Type_of_review'];?></td>
								<td><a href="view_submit_app.php?id=<?php echo $result[0];?>">view more </a></td>
                                                                <td><select class="form-control" id="sel1" name="status">
										<option>choose</option>
										<option value="approved">approved</option>
										<option value="Rejected">rejected</option>
                                                                                <option value="approved with condition">approved with condition</option>
										</select></td>
                                                                <td><input type="submit" name="submit" class="submit_btn" value="submit" /></td>
									
							</tr>	
							<?php		
								}
								?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			 </div>			   
<?php
include('footer.php');
?>
