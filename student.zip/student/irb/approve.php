<?php
	include('../connection.php');
		$appid=$_REQUEST['id'];
		$sql="UPDATE admin_send_irb_faculty set status =1 WHERE irbmember ='$appid'";
		$res=mysql_query($sql);
		if($res)
			{
				echo "<script>alert('Accept request'); window.location='view_review_request_faculty.php'</script>";
			}
			else
			{
				echo "<script>alert('Accept request error'); window.location='view_review_request_faculty.php'</script>";
			}

?>