<?php

error_reporting(0);
$conn=mysql_connect("localhost" ,"root","");


if(!$conn)
{
	
	
	echo 'couldnot connect'.mysql_error();
}

mysql_select_db('irb approval system');



?>